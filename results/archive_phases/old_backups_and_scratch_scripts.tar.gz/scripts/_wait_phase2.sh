#!/usr/bin/env bash
# Wait for the phase2 screen to finish, then print the validation summary.
set -u
cd /home/sultra/atlas_main
LOG=$(ls results/phase2/lbfgs/*_screen.log 2>/dev/null | head -1)
[ -z "$LOG" ] && LOG=results/phase2/lbfgs/l_bracket_screen.log
echo "waiting on: $LOG"
for i in $(seq 1 600); do
  if grep -q 'DISPLACEMENT L2\|ALL_PHYSICS\|PHASE2_SCREEN_DONE\|relative L1' "$LOG" 2>/dev/null \
     || ! ps -eo args | grep -q 'validate_all_benchmarks'; then
    echo "=== done-resume detected at poll $i ==="
    break
  fi
  sleep 10
done
echo "---- results ----"
grep -E 'Relative L2 error \(' "$LOG" | tail -8
echo "==== end ===="
