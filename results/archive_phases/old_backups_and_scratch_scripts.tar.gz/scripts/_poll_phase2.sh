#!/usr/bin/env bash
# Driver: poll Phase-2 screen until every benchmark validation JSON exists,
# then extract the headline numbers for the comparison table.
set -u
cd /home/sultra/atlas_main
LOGSDIR=results/phase2/lbfgs
OK=0
for i in $(seq 1 900); do
  OK=1
  for bench in l_bracket plate_hole; do
    [ -f "$LOGSDIR/${bench}_validation.json" ] || { OK=0; break; }
  done
  [ $OK -eq 1 ] && break
  sleep 10
done
echo "POLL_EXIT ok=$OK polled_until=$(date '+%Y-%m-%d %H:%M:%S')"
for bench in l_bracket plate_hole; do
  V="$LOGSDIR/${bench}_validation.json"
  if [ -f "$V" ]; then
    echo "== $bench =="
    /home/sultra/miniconda3/envs/Atlas/bin/python -c "import json,sys; d=json.load(open('$V')); print('  disp:', d.get('relative_L2_displacement')); print('  vm_excl:', d.get('von_mises_l2_excl')); print('  disp_ok:', d.get('displacement_within_5pct_target')); print('  vm_excl_ok:', d.get('von_mises_l2_excl_within_10pct'))"
  else
    echo "== $bench MISSING =="
  fi
done
echo "PHASE2_POLL_DONE $(date '+%Y-%m-%d %H:%M:%S')"
