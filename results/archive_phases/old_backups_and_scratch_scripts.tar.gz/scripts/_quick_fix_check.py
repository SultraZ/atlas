"""Throwaway quick-check for the strip-quadrature fix: short MPE train on cuda,
then loaded-face amplification ratio + energy-balance signals."""
import os
import sys
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from atlas.atlas_main import train_forward_solver, _plate_hole_energy_context
from atlas.loss_functions import XPINNLoss
from atlas.physics import PlaneStressElasticity
from atlas.paths import FEM_REFERENCE_DIR

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"device={device}")
torch.manual_seed(42)
np.random.seed(42)

model, trainer, sampler, phys = train_forward_solver(
    'plate_hole', device=device, epochs=250, print_every=50,
    n_interior=800, n_boundary=150, n_interface=80,
    use_lbfgs=False, use_mpe=True)
net = model.get_subdomain_network(0)
print("PI_end_adam:", [round(float(h), 4) for h in trainer.history['energy'][-5:]])

# quick-validate vs FEM ref bridge points
coords = np.load(os.path.join(FEM_REFERENCE_DIR, 'plate_hole_coords.npy')).reshape(-1, 2)
u_ref = np.load(os.path.join(FEM_REFERENCE_DIR, 'plate_hole_u.npy')).reshape(-1)
v_ref = np.load(os.path.join(FEM_REFERENCE_DIR, 'plate_hole_v.npy')).reshape(-1)
with torch.no_grad():
    up = net(torch.tensor(coords, dtype=torch.float32, device=device)).cpu().numpy()
mask = np.abs(coords[:, 0] - coords[:, 0].max()) < 1e-9
pm = np.linalg.norm(up[mask], axis=1)
rm = np.linalg.norm(np.stack([u_ref[mask], v_ref[mask]], axis=1), axis=1)
print(f"loaded-face pred/ref ratio = {pm.mean()/max(rm.mean(),1e-30):.3f}  "
      f"(cheat was 104; exact ~ 1)")
print("QUICK CHECK OK")