#!/usr/bin/env bash
set -u
cd /home/sultra/atlas_main
export PYTHONUNBUFFERED=1
PY=/home/sultra/miniconda3/envs/Atlas/bin/python
PHASE=${1:-phase1}
EPOCHS=${2:-2000}
CFG=${3:-lbfgs}
BENCHES=${4:-"cantilever l_bracket plate_hole"}
LBFGS_FLAG=""
[ "$CFG" = "lbfgs" ] && LBFGS_FLAG="--lbfgs"

for bench in $BENCHES; do
  echo "================ $(date '+%Y-%m-%d %H:%M:%S') :: $PHASE :: $CFG :: $bench (epochs=$EPOCHS) ================"
  timeout 1800 $PY tests/validate_all_benchmarks.py --benchmark "$bench" --epochs "$EPOCHS" $LBFGS_FLAG
  echo "python rc=$?"
  mkdir -p "results/$PHASE/$CFG"
  for f in validation.json model.pt convergence.png fem_comparison.png displacement.png stress.png deformed.png; do
    if [ -f "results/${bench}_${f}" ]; then
      cp "results/${bench}_${f}" "results/$PHASE/$CFG/${bench}_${f}"
    fi
  done
  rm -f results/${bench}_validation.json results/${bench}_model.pt results/${bench}_*.png
  echo "SNAPSHOT done $PHASE $CFG $bench"
done

echo "${PHASE^^}_DONE $(date '+%Y-%m-%d %H:%M:%S')"
