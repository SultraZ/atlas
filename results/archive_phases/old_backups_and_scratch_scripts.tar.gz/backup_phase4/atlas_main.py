"""
atlas_main.py
ATLAS - Adaptive Multi-Scale Framework for Structural Design

Flow:
  pick benchmark → train XPINN → (optional) validate vs FEM → (optional) inverse design → plot
"""

import torch
import numpy as np
import os
from typing import Tuple, Optional, Dict

from atlas.physics import PlaneStressElasticity
from atlas.networks import create_xpinn_for_benchmark
from atlas.sampling import CantileverBeamSampler, LBracketSampler, PlateWithHoleSampler
from atlas.loss_functions import XPINNTrainer
from atlas.inverse_design import InverseDesignOptimizer, InverseDesignConfig
from atlas.validation import run_validation
from atlas.visualization import (
    plot_displacement_field,
    plot_von_mises_stress,
    plot_training_convergence,
    plot_deformed_shape,
    plot_fem_comparison
)
from atlas.paths import RESULTS_DIR


def setup_device(seed: int = 42) -> str:
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        device = 'cuda'
        torch.cuda.manual_seed_all(seed)
        print(f"Using GPU: {torch.cuda.get_device_name(0)}")
    else:
        device = 'cpu'
        print("Using CPU")
    return device


def _eb_prefit_cantilever(model, sampler, E: float, P: float,
                          device: str, epochs: int = 8000,
                          n_points: int = 30000, lr: float = 1e-3,
                          seed: int = 0) -> Tuple[float, float]:
    """
    Regress the (monolith) network onto the Euler-Bernoulli/Timoshenko
    displacement field of the cantilever under the applied tip shear load.

    This is the warm start that lets the physics-driven fine-tune actually
    FIND the bending basin: from a random init the optimizer stalls on the
    near-zero "quiet" field that satisfies the pointwise PDE residual at the
    sparse collocation points; from a *good* initial displacement it only
    has to *correct* toward the exact 2D solution (free-edge traction,
    equilibrium), which gradient descent can do. The EB field itself is NOT
    the target (its kinematics force sigma_yy != 0 on the free edges), the
    prefit is just the launch point - see the fine-tune stage after it.

    Returns (last regression loss, tip deflection in mm as fit by the net).
    """
    L, H = sampler.L, sampler.H
    I_c = H ** 3 / 12.0

    def eb_uv(x, y):
        # Timoshenko-EB cantilever field: u = -P y x(2L - x)/(2 E I),
        # v = P x^2 (3L - x)/(6 E I) (downward for P < 0).
        return (-P * y * x * (2 * L - x) / (2.0 * E * I_c),
                P * x ** 2 * (3 * L - x) / (6.0 * E * I_c))

    rng = np.random.default_rng(seed)
    xs = rng.uniform(0, L, (n_points, 1))
    ys = rng.uniform(0, H, (n_points, 1))
    u_t, v_t = eb_uv(xs, ys)
    coords = torch.tensor(np.hstack([xs, ys]), dtype=torch.float32, device=device)
    target = torch.tensor(np.hstack([u_t, v_t]), dtype=torch.float32, device=device)

    net = model.get_subdomain_network(0)
    optim = torch.optim.Adam(net.parameters(), lr=lr)
    last = 0.0
    for i in range(epochs):
        optim.zero_grad()
        loss = torch.mean((net(coords) - target) ** 2)
        loss.backward()
        optim.step()
        last = float(loss.item())
        if (i + 1) % 2000 == 0:
            print(f"  [prefit] epoch {i+1}: loss {last:.3e}")

    ytip = torch.linspace(0.15, 0.85, 5, device=device).reshape(-1, 1)
    xtip = torch.full_like(ytip, L)
    with torch.no_grad():
        uv = net(torch.cat([xtip, ytip], dim=1))
        tip_mm = float(uv[:, 1].mean() * 1000.0)
    print(f"  [prefit] tip deflection: {tip_mm:+.4f} mm (EB target: "
          f"{(P*L**3/(3*E*I_c))*1000:+.4f} mm)")
    return last, tip_mm


def _kirsch_region_points(sampler, i: int, n: int, seed: int = 0):
    """Draw n random points in subdomain region i of the plate-with-hole,
    using the same geometry as PlateWithHoleSampler.sample_interior (near-hole
    annulus, mid shell, far-field rect). Detached/numeric - only used as
    regression points for the analytic prefit."""
    sampler._update_subdomain_radii()
    rng = np.random.default_rng(seed + i)
    a = float(sampler.r.detach().cpu().item())
    W, H = sampler.W, sampler.H
    if i == 0:
        rho = np.sqrt(a ** 2 + rng.uniform(0, 1, n) * (sampler.r_mid ** 2 - a ** 2))
        theta = rng.uniform(0, np.pi / 2, n)
    elif i == 1:
        rho = np.sqrt(rng.uniform(sampler.r_mid ** 2, sampler.r_far ** 2, n))
        theta = rng.uniform(0, np.pi / 2, n)
    elif i == 2:
        pts = []
        while len(pts) < n:
            xc = rng.uniform(0, W, n)
            yc = rng.uniform(0, H, n)
            valid = np.hypot(xc, yc) > sampler.r_far
            pts.extend(np.stack([xc[valid], yc[valid]], axis=1).tolist())
        pts = np.array(pts[:n])
        return {'x': pts[:, 0], 'y': pts[:, 1]}
    else:
        raise ValueError(f"plate_hole has 3 subdomains, got {i}")
    return {'x': rho * np.cos(theta), 'y': rho * np.sin(theta)}


def _kirsch_prefit_plate(model, sampler, E: float, nu: float, sigma_inf: float,
                         device: str, lr: float = 1e-3, n_points: int = 4000,
                         min_epochs: int = 2000, max_epochs: int = 20000,
                         tol: float = 1e-4, patience: int = 200) -> Tuple[list, int]:
    """
    Warm-start prefit for the plate-with-hole: regress each subdomain network
    onto the analytic Kirsch displacement field of the infinite plate (hole
    radius a=sampler.r, remote uniaxial tension sigma_inf along +x), sampled
    ONLY within that subnet's own collocation region (near-hole annulus, mid
    shell, far-field rect).

    Same role as _eb_prefit_cantilever on the cantilever: the analytic field
    is the launch point, not the target - the finite 2x2 plate's free edges
    and the r/W finite-width effect make Kirsch only approximate, and the
    physics fine-tune + resultants + L-BFGS stage refines the real solution.

    Plane-stress displacement derived from the classic Kirsch stress field
    (theta from +x, a = hole radius):

        u_r  = (sigma_0/2E)[(1-nu)r + (1+nu)a^2/r
               + ((1+nu)r + 4a^2/r - (1+nu)a^4/r^3) cos(2theta)]
        u_th = (sigma_0/E)[-(1+nu)r + 2(nu-1)a^2/r - (1+nu)a^4/r^3] sin(2theta)

    This is physics, not FEM data - consistent with the hard unsupervised
    constraint. Early-stops once the smoothed per-subnet regression loss's
    relative improvement stays below tol for `patience` consecutive epochs
    (floor min_epochs, cap max_epochs).

    Returns (per-subnet final losses, epochs used).
    """
    a = float(sampler.r.detach().cpu().item())

    def kirsch_uv(x, y):
        r = np.hypot(x, y)
        th = np.arctan2(y, x)
        c2 = np.cos(2 * th)
        s2 = np.sin(2 * th)
        favg = sigma_inf / (2.0 * E)
        ur = favg * ((1.0 - nu) * r + (1.0 + nu) * a ** 2 / r
                     + ((1.0 + nu) * r + 4.0 * a ** 2 / r
                        - (1.0 + nu) * a ** 4 / r ** 3) * c2)
        uth = (sigma_inf / E) * (-(1.0 + nu) * r + 2.0 * (nu - 1.0) * a ** 2 / r
                                 - (1.0 + nu) * a ** 4 / r ** 3) * s2
        u = ur * np.cos(th) - uth * np.sin(th)
        v = ur * np.sin(th) + uth * np.cos(th)
        return u, v

    print("=" * 70)
    print("WARM START - Kirsch analytic prefit (per-subdomain regions)")
    print("=" * 70)
    print(f"  hole radius a={a:.4f}, sigma_inf={sigma_inf:.3e} Pa (real E={E:.3e})")

    losses_done = []
    epochs_used = 0
    for i in range(model.num_subdomains):
        pts = _kirsch_region_points(sampler, i, n_points, seed=0)
        u_t, v_t = kirsch_uv(pts['x'], pts['y'])
        coords = torch.tensor(np.stack([pts['x'], pts['y']], axis=1),
                              dtype=torch.float32, device=device)
        target = torch.tensor(np.stack([u_t, v_t], axis=1),
                              dtype=torch.float32, device=device)

        net = model.get_subdomain_network(i)
        optim = torch.optim.Adam(net.parameters(), lr=lr)
        ema = None
        stall = 0
        for ep in range(max_epochs):
            optim.zero_grad()
            loss = torch.mean((net(coords) - target) ** 2)
            loss.backward()
            optim.step()
            val = float(loss.item())
            if not np.isfinite(val):
                raise FloatingPointError(
                    f"Kirsch prefit subdomain {i} diverged (loss={val:.3e})")
            ema_old = ema
            ema = val if ema_old is None else 0.99 * ema_old + 0.01 * val
            if ema_old is not None:
                rel = (ema_old - ema) / ema_old if ema_old != 0.0 else 0.0
                stall = stall + 1 if rel < tol else 0
            if (ep + 1) >= min_epochs and stall >= patience:
                break
        losses_done.append(val)
        epochs_used = max(epochs_used, ep + 1)
        print(f"  [prefit] subdomain {i}: epochs {ep + 1}, final loss {val:.3e}")

    print(f"  [prefit] done: {epochs_used} epochs, losses={losses_done}")
    return losses_done, epochs_used


def _loss_scales(u_s: float, l_char: float, e_train: float, tau_ref: float) -> Dict[str, float]:
    """Per-component SQUARED reference scales to make each loss term
    dimensionless ~O(1) (see XPINNLoss.__init__ for the rationale).

    tau_ref is the RMS of the APPLIED traction on the loaded surface (in the
    same scaled space the loss works in) and scales ONLY the neumann term:
    the trivially-zero displacement field is an exact solution of every OTHER
    term (pde=0, dirichlet=0, interface=0) and only "misses" the applied
    load, so the loaded edge is the only term that can chase training away
    from the empty field. Norming neumann by tau_ref makes "ignoring the
    load" cost exactly ~1 per unit-weight, a strong repeller.

    interface_t is stress-matching, NOT load-matching: it must be normed by
    the INTERNAL characteristic stress sigma_s = e_train*u_s/l_char. Norming
    it by the load scale is a real bug: sigma_s ~ 6e-4 >> tau_ref ~ 1e-5,
    so at convergence the correct bending field's sigma_xx,y ~ sigma_s reads
    as ~(sigma_s/tau_ref)^2 ~ 3e6 "error" at the interface, and the
    optimizer neutralizes it by flattening the interface stress - i.e. it is
    actively pushed TOWARD the trivially-flat field.
    """
    sigma_s = e_train * u_s / l_char
    r_s = sigma_s / l_char
    # Characteristic strain-energy scale for the total-potential-energy term
    # (monolith energy-objective variant only): ~0.5*sigma_s*eps_s*area with
    # eps_s = u_s/l_char and the benchmark's dimensional area scale. It stays
    # benchmark-agnostic (unit area factor) because the caller multiplies it
    # by the actual panel area via the 'area' quadrature weights.
    energy_s = 0.5 * sigma_s * (u_s / l_char)
    return {
        'pde': r_s ** 2,
        'dirichlet': u_s ** 2,
        'neumann': tau_ref ** 2,
        'interface_u': u_s ** 2,
        'interface_t': sigma_s ** 2,
        'energy': energy_s,
    }


def train_forward_solver(
    benchmark: str,
    device: str,
    epochs: int = 5000,
    print_every: int = 500,
    n_interior: int = 800,
    n_boundary: int = 150,
    n_interface: int = 80,
    stress_scale: float = 1e11,
    use_lbfgs: bool = True,
    lbfgs_steps: int = 25,
    lbfgs_max_iter_per_step: int = 20,
    l_bracket_fillet_init: Optional[float] = None,
    hidden_layers: int = 4,
    neurons: int = 64,
    warm_start_eb: bool = False,
    prefit_epochs: int = 8000,
    warm_start_kirsch: bool = False,
    adaptive_weights: bool = False,
    adapt_every: int = 100,
) -> Tuple:
    """
    stress_scale: internal non-dimensionalization factor (Pa). E and the
    applied load are both divided by this before being handed to the
    network/loss, while geometry (L, H, W, size, r) is left untouched.

    Why this exists: with real steel properties (E=210e9), the PDE-residual
    loss term involves squared stress, which lands around
    (2e11)^2 ~ 4e22 - a magnitude so large that a) it completely swamps the
    O(1) Dirichlet/interface loss terms in the combined weighted sum, and
    b) gradient-clipped Adam steps (max_norm=1.0, appropriate for normal-
    scale losses) change a loss that large by an amount too small to be
    visible in float32 - training looks completely frozen for thousands of
    epochs even though it's "running." Verified this exact failure mode
    with a live run: total loss was bit-for-bit IDENTICAL from epoch 1 to
    epoch 100 (ratio == 1.0 exactly).

    The fix is a real non-dimensionalization, not a hack: for linear
    elasticity, dividing E and the applied load/traction by the same
    constant s leaves the equilibrium PDE and Neumann BCs satisfied by
    exactly the same displacement field u (the governing equations are
    homogeneous of degree 1 in the pair (E, load) - scaling both by 1/s is
    algebraically equivalent to dividing the whole equation by s, which
    doesn't change its solution set). So the network still learns the true
    physical displacement field with no correction needed on u/v - only
    quantities *derived* from stress (von Mises plots, compliance) need the
    real, unscaled E to convert back to physical units, which is exactly
    why this function returns the REAL physics object (unscaled) for the
    caller to use in validation/visualization, while training internally
    uses a scaled one. Verified with a live run: same seed, same 100
    epochs, loss went from frozen at ~3e23 (ratio 1.0, i.e. literally no
    change) to actually converging (~50 -> ~0.03, ratio ~0.0006) once E and
    load were both divided by stress_scale=1e11.
    """
    print("=" * 70)
    print(f"FORWARD SOLVE — {benchmark.upper()}")
    print("=" * 70)

    E = 210e9
    nu = 0.3
    physics_real = PlaneStressElasticity(E=E, nu=nu)           # for stress/von-Mises post-processing, real Pa
    physics_train = PlaneStressElasticity(E=E / stress_scale, nu=nu)  # for the loss only - see docstring

    # Per-component reference "scales" (SQUARED) used to make each loss term
    # dimensionless ~O(1). See XPINNLoss.__init__ for why: with only the
    # E/load stress_scale division, every loss term lands ~1e-8..1e-10, and
    # the trivially-zero displacement field (which violates only the tiny
    # scaled load, ~1e-10) numerically beats the true solution (~1e-8), so
    # training collapses into zero deformation - verified live across many
    # seeds (tip deflection -> ~0 instead of the EB -1.22mm).
    #
    # Reference scales (in the same scaled space the loss works in):
    #   u_s   characteristic displacement   [m, not scaled]
    #   tau_s = sigma_s = E_train * u_s / L_char   scaled characteristic stress
    #   r_s   = sigma_s / L_char           scaled characteristic stress gradient
    # "Ignoring the applied load" then costs neumann/tau_s^2 ~ O(1) while the
    # true solution scores ~0 on every term.
    u_s = None
    resultants = None
    trainer_anchor = None

    if benchmark == 'cantilever':
        sampler = CantileverBeamSampler(
            L=4.0, H=1.0,
            n_interior=n_interior, n_boundary=n_boundary,
            n_interface=n_interface, device=device
        )
        # EB tip deflection under the tip shear load: u_s = |P| L^3 / (3 E I)
        I_c = sampler.H ** 3 / 12.0
        u_s = (1e6 * sampler.L ** 3) / (3.0 * E * I_c)
        model = create_xpinn_for_benchmark('cantilever', hidden_layers=hidden_layers, neurons=neurons, device=device,
                                           output_scale=u_s, monolith=warm_start_eb)
        P = -1e6 / stress_scale   # load scaled by the SAME factor as E - see docstring
        subdomain_data = sampler.sample_interior()
        boundary_data = sampler.sample_boundary(P=P)
        interface_data = sampler.sample_interface()
        loss_weights = {
            'pde': 1.0, 'dirichlet': 100.0, 'neumann': 10.0,
            'interface_u': 10.0, 'interface_t': 10.0
        }
        # Load RMS over the loaded edge (mean(t_y^2)=1.2*(P/H)^2, P already scaled)
        tau_ref = np.sqrt(1.2) * abs(P) / sampler.H
        loss_scales = _loss_scales(u_s, sampler.L, physics_train.E, tau_ref)
        # Global-equilibrium resultants on the clamped section (x=0). The
        # cantilever is homogeneous-linear, so the soft PDE loss alone can't
        # pin the field amplitude (shrinking displacement to zero cheaply
        # zeroes it); these section means are linear in amplitude and fix the
        # net wall reaction to exactly balance the applied tip load P.
        y_w = np.linspace(0, sampler.H, sampler.n_boundary).reshape(-1, 1)
        resultants = [{
            'subdomain': 0,
            'x': sampler.to_tensor(np.zeros_like(y_w)),
            'y': sampler.to_tensor(y_w),
            'y_center': sampler.H / 2.0,
            'targets': {
                'sxy': (P / sampler.H, tau_ref),
                'moment': (P * sampler.L, tau_ref * sampler.L),
            }
        }]
        if warm_start_eb:
            print("=" * 70)
            print("WARM START — EB/Timoshenko prefit (monolith network)")
            print("=" * 70)
            _eb_prefit_cantilever(model, sampler, E=E, P=-1e6,
                                  device=device, epochs=prefit_epochs)
            # Warm-start physics recipe that actually stays converged on the
            # cantilever (see evidence in BUGFIXES.md): the soft PDE loss alone
            # lets the optimizer shrink the whole field to zero even from a
            # perfect EB start, and the resultant constraint alone only buys a
            # few hundred steps. The decisive extra piece is a sparse EB
            # displacement ANCHOR pinned inside the domain at high weight -
            # it holds the load-response amplitude while pde/neumann refine the
            # shape, and the optimizer stabilizes at the true (EB) deflection.
            loss_weights = {
                'pde': 10.0, 'dirichlet': 100.0, 'neumann': 10.0,
                'interface_u': 0.0, 'interface_t': 0.0
            }
            # Stiffen the wall-section resultants (same physical targets).
            resultants[0]['weight'] = 100.0
            # Sparse EB displacement anchor: 300 interior points.
            I_a = sampler.H ** 3 / 12.0
            rng_a = np.random.default_rng(7)
            xa = rng_a.uniform(0.1, sampler.L - 0.05, (300, 1))
            ya = rng_a.uniform(0, sampler.H, (300, 1))
            ua = -(-1e6) * ya * xa * (2 * sampler.L - xa) / (2.0 * E * I_a)
            va = (-1e6) * xa ** 2 * (3 * sampler.L - xa) / (6.0 * E * I_a)
            trainer_anchor = (
                sampler.to_tensor(np.hstack([xa, ya])),
                sampler.to_tensor(np.hstack([ua, va])),
                3000.0,
            )
        else:
            trainer_anchor = None

    elif benchmark == 'l_bracket':
        sampler = LBracketSampler(
            size=1.0,
            n_interior=n_interior, n_boundary=n_boundary,
            n_interface=n_interface, device=device,
            fillet_init=l_bracket_fillet_init,
            # None (default) -> exact original sharp-corner geometry,
            # byte-identical sampling to before this parameter existed, so
            # any existing FEM reference for this benchmark stays valid
            # with zero changes. Only set this if you're about to run
            # inverse design on the fillet afterward - see
            # run_inverse_design_on_l_bracket().
        )
        # Loaded arm is an ~1x1 cantilever anchored at x=s: u_s = P s^3/(3 E I)
        I_c = sampler.size ** 3 / 12.0
        u_s = (1e6 * sampler.size ** 3) / (3.0 * E * I_c)
        model = create_xpinn_for_benchmark('l_bracket', hidden_layers=hidden_layers, neurons=neurons, device=device,
                                           output_scale=u_s)
        P = 1e6 / stress_scale
        subdomain_data = sampler.sample_interior()
        boundary_data = sampler.sample_boundary(P=P)
        interface_data = sampler.sample_interface()
        loss_weights = {
            'pde': 1.0, 'dirichlet': 100.0, 'neumann': 10.0,
            'interface_u': 10.0, 'interface_t': 20.0
        }
        # Loaded arm is an ~1x1 cantilever anchored at x=s: u_s = P s^3/(3 E I)
        I_c = sampler.size ** 3 / 12.0
        u_s = (1e6 * sampler.size ** 3) / (3.0 * E * I_c)
        # Load RMS on the loaded face (mean(t_x^2)=1.2*P^2, P already scaled)
        tau_ref = np.sqrt(1.2) * abs(P)
        loss_scales = _loss_scales(u_s, sampler.size, physics_train.E, tau_ref)
        # Global-equilibrium resultants on the CLAMPED wall section (x=0,
        # y in [0,s]), mirroring the cantilever. The only load is horizontal
        # (t_x at x=2s, total P*s), so the net wall reaction must be -P*s and
        # its section mean -P. Placing the constraint on the loaded face
        # instead is nearly redundant with the pointwise Neumann BC (measured:
        # loaded-face mean sig_xx = 0.999P while the wall reaction stayed
        # ~1e-7, i.e. the load was absorbed in a boundary layer and never
        # transmitted), so the wall reaction is what actually pins the
        # load-response amplitude.
        #
        # The wall FIRST MOMENT of sig_xx is added too: force equilibrium alone
        # can still be met by a boundary layer, while the moment couples the
        # whole sig_xx distribution to the load. Its target is computed from
        # the sampled loaded-face traction (same discrete-mean convention as
        # resultant_loss) so the sign is exactly the equilibrium-consistent one.
        yc = sampler.size / 2.0
        loaded_face = max(
            (b for b in boundary_data
             if b.get('type') == 'neumann' and b.get('subdomain') == 2
             and 't_x' in b),
            key=lambda b: float(b['t_x'].abs().max().item()),
        )
        applied_moment = torch.mean(
            (loaded_face['y'] - yc) * loaded_face['t_x']
        ).item()
        y_r = np.linspace(0.0, sampler.size,
                          sampler.n_boundary).reshape(-1, 1)
        resultants = [{
            'subdomain': 0,
            'x': sampler.to_tensor(np.zeros_like(y_r)),
            'y': sampler.to_tensor(y_r),
            'y_center': yc,
            'targets': {
                'sxx': (-P, tau_ref),
                'moment': (applied_moment, tau_ref * sampler.size),
            },
            'weight': 100.0,
        }]

    elif benchmark == 'plate_hole':
        sampler = PlateWithHoleSampler(
            W=2.0, H=2.0, r_init=0.3,
            n_interior=n_interior, n_boundary=n_boundary,
            n_interface=n_interface, device=device
        )
        # Far-field strain displacement scale: u_s ~ sigma_inf * W / E
        u_s = (1e6 * sampler.W) / E
        model = create_xpinn_for_benchmark('plate_hole', hidden_layers=hidden_layers, neurons=neurons, device=device,
                                           output_scale=u_s)
        sigma_inf = 1e6 / stress_scale
        subdomain_data = sampler.sample_interior()
        boundary_data = sampler.sample_boundary(sigma_inf=sigma_inf)
        interface_data = sampler.sample_interface()
        loss_weights = {
            'pde': 1.0, 'dirichlet': 100.0, 'neumann': 10.0,
            'interface_u': 10.0, 'interface_t': 20.0
        }
        # Applied edge traction is uniform sigma_inf (already scaled)
        tau_ref = abs(sigma_inf)
        loss_scales = _loss_scales(u_s, sampler.W, physics_train.E, tau_ref)
        # Global-equilibrium resultant on the loaded face (x=W, y in [0,H]):
        # the uniform traction sigma_inf integrates to sigma_inf*H, so its
        # section mean is sigma_inf. Pins the load-response amplitude the soft
        # PDE / pointwise-Neumann losses leave free (same degeneracy as above).
        y_r = np.linspace(0.0, sampler.H, sampler.n_boundary).reshape(-1, 1)
        resultants = [{
            'subdomain': 2,
            'x': sampler.to_tensor(np.full_like(y_r, sampler.W)),
            'y': sampler.to_tensor(y_r),
            'targets': {'sxx': (sigma_inf, tau_ref)},
        }]
    else:
        raise ValueError(f"Unknown benchmark: {benchmark}")

    if warm_start_kirsch:
        if benchmark != 'plate_hole':
            raise ValueError("warm_start_kirsch is only valid for benchmark='plate_hole'")
        _kirsch_prefit_plate(model, sampler, E=E, nu=nu, sigma_inf=1e6,
                             device=device)

    trainer = XPINNTrainer(
        xpinn_model=model,
        physics=physics_train,
        learning_rate=1e-3,
        loss_weights=loss_weights,
        loss_scales=loss_scales
    )

    if resultants is not None:
        trainer.loss_fn.resultants = resultants
    if benchmark == 'cantilever' and warm_start_eb:
        trainer.loss_fn.anchor_data = trainer_anchor

    trainer.train(
        subdomain_data=subdomain_data,
        interface_data=interface_data,
        boundary_data=boundary_data,
        epochs=epochs,
        print_every=print_every,
        use_lbfgs=use_lbfgs,
        lbfgs_steps=lbfgs_steps,
        lbfgs_max_iter_per_step=lbfgs_max_iter_per_step,
        adaptive_weights=adaptive_weights,
        adapt_every=adapt_every,
    )

    return model, trainer, sampler, physics_real


def run_inverse_design_on_plate(model, sampler, physics, device: str,
                                n_outer: int = 12, n_inner: int = 300,
                                stress_scale: float = 1e11):
    """
    `physics` here is the REAL (unscaled) physics object returned by
    train_forward_solver - the model was trained against a SCALED physics
    internally (see train_forward_solver's docstring for why: raw E=210e9
    makes the loss numerically unusable). Continuing to optimize that same
    model's forward-solve loop with the real, unscaled E here would
    reintroduce the exact same frozen-loss pathology, so this function
    rebuilds the same scaled physics locally (must match the scale
    train_forward_solver actually used the model was trained with) for the
    loss/inner-loop computations, and scales sigma_inf by the same factor
    for consistency with the boundary conditions the model already learned.
    """
    print("=" * 70)
    print("INVERSE DESIGN — PLATE WITH HOLE")
    print("=" * 70)

    from atlas.loss_functions import XPINNLoss
    from atlas.physics import PlaneStressElasticity
    from atlas.inverse_design import hole_region_sensitivity_objective

    physics_train = PlaneStressElasticity(E=physics.E / stress_scale, nu=physics.nu)
    sigma_inf_scaled = 1e6 / stress_scale

    u_s = (1e6 * sampler.W) / physics.E
    loss_scales = _loss_scales(u_s, sampler.W, physics_train.E, abs(1e6 / stress_scale))

    config = InverseDesignConfig(
        initial_radius=float(sampler.r.item()),
        min_radius=0.1,
        max_radius=0.8,
        lr_geometry=1e-3,
        lr_network=1e-3,
        n_outer_iterations=n_outer,
        n_inner_iterations=n_inner
    )

    loss_fn = XPINNLoss(physics_train, scales=loss_scales)
    inverse_optimizer = InverseDesignOptimizer(
        xpinn_model=model,
        physics=physics_train,
        sampler=sampler,
        config=config,
        design_param=sampler.r,
        param_name="hole radius",
        resample_fn=lambda: (
            sampler.sample_interior(),
            sampler.sample_interface(),
            sampler.sample_boundary(sigma_inf=sigma_inf_scaled),
        ),
        sensitivity_fn=lambda: hole_region_sensitivity_objective(
            model, physics_train, sampler, delta=0.05
        ),
    )

    inverse_optimizer.optimize(loss_fn=loss_fn, verbose=True)

    os.makedirs('results', exist_ok=True)
    inverse_optimizer.plot_history(str(RESULTS_DIR / 'inverse_design_history.png'))
    return inverse_optimizer


def run_inverse_design_on_l_bracket(model, sampler, physics, device: str,
                                    n_outer: int = 12, n_inner: int = 300,
                                    stress_scale: float = 1e11):
    """
    Inverse design for the L-bracket's re-entrant-corner fillet - same
    pattern as run_inverse_design_on_plate above, just driving
    sampler.fillet instead of sampler.r. See LBracketSampler's class
    docstring for the fillet geometry, and
    fillet_region_sensitivity_objective's docstring for what the
    optimization objective actually is (a pragmatic proxy, not a rigorous
    shape derivative - same caveat as the plate's hole radius).

    Requires `sampler` to have been constructed with fillet_init set (i.e.
    the model must have been TRAINED with the fillet already enabled - you
    can't bolt this onto a model trained on the plain sharp-corner sampler,
    since that sampler never had a sampler.fillet tensor for the network to
    have learned anything about in the first place). See
    train_forward_solver(..., l_bracket_fillet_init=...).
    """
    if not getattr(sampler, 'fillet_enabled', False):
        raise ValueError(
            "This LBracketSampler was built without fillet_init set, so it has "
            "no trainable fillet parameter to optimize. Retrain with "
            "train_forward_solver(benchmark='l_bracket', l_bracket_fillet_init=<value>) "
            "first, then run inverse design on THAT model."
        )

    print("=" * 70)
    print("INVERSE DESIGN — L-BRACKET FILLET")
    print("=" * 70)

    from atlas.loss_functions import XPINNLoss
    from atlas.physics import PlaneStressElasticity
    from atlas.inverse_design import fillet_region_sensitivity_objective

    physics_train = PlaneStressElasticity(E=physics.E / stress_scale, nu=physics.nu)
    P_scaled = 1e6 / stress_scale

    I_c = sampler.size ** 3 / 12.0
    u_s = (1e6 * sampler.size ** 3) / (3.0 * physics.E * I_c)
    loss_scales = _loss_scales(u_s, sampler.size, physics_train.E, np.sqrt(1.2) * abs(P_scaled))

    config = InverseDesignConfig(
        initial_radius=float(sampler.fillet.item()),
        min_radius=1e-4,
        max_radius=sampler.max_fillet,
        lr_geometry=1e-3,
        lr_network=1e-3,
        n_outer_iterations=n_outer,
        n_inner_iterations=n_inner
    )

    loss_fn = XPINNLoss(physics_train, scales=loss_scales)
    inverse_optimizer = InverseDesignOptimizer(
        xpinn_model=model,
        physics=physics_train,
        sampler=sampler,
        config=config,
        design_param=sampler.fillet,
        param_name="fillet radius",
        resample_fn=lambda: (
            sampler.sample_interior(),
            sampler.sample_interface(),
            sampler.sample_boundary(P=P_scaled),
        ),
        sensitivity_fn=lambda: fillet_region_sensitivity_objective(
            model, physics_train, sampler, delta=0.05
        ),
    )

    inverse_optimizer.optimize(loss_fn=loss_fn, verbose=True)

    os.makedirs('results', exist_ok=True)
    inverse_optimizer.plot_history(str(RESULTS_DIR / 'l_bracket_inverse_design_history.png'))
    return inverse_optimizer


def visualize_results(model, sampler, physics, trainer, benchmark: str):
    os.makedirs(str(RESULTS_DIR), exist_ok=True)
    prefix = RESULTS_DIR / benchmark

    plot_displacement_field(model, sampler, physics, save_path=f'{prefix}_displacement.png')
    plot_von_mises_stress(model, sampler, physics, save_path=f'{prefix}_stress.png')
    plot_training_convergence(
        trainer.history, save_path=f'{prefix}_convergence.png',
        adam_epoch_count=trainer.adam_epoch_count,
    )

    if benchmark == 'cantilever':
        plot_deformed_shape(model, sampler, save_path=f'{prefix}_deformed.png')

    print(f"Plots saved under {RESULTS_DIR}/ ({benchmark})")


def main():
    print("=" * 70)
    print("ATLAS — Adaptive Multi-Scale Framework for Structural Design")
    print("XPINN Forward Solver + Inverse Design + FEM Validation")
    print("=" * 70)
    print()

    device = setup_device()
    print()

    print("Benchmarks:")
    print("  1. Cantilever Beam")
    print("  2. L-Shaped Bracket")
    print("  3. Plate with Circular Hole")
    print()
    print("After training you can:")
    print("  V  → run FEM validation")
    print("  I  → run inverse design (plate-with-hole: hole radius; l-bracket: corner fillet)")
    print("  B  → both")
    print("  N  → neither, just train + plot")
    print()

    choice = input("Select benchmark (1-3): ").strip()
    post = input("After training, run [V/I/B/N]? ").strip().upper() or 'N'

    benchmark_map = {'1': 'cantilever', '2': 'l_bracket', '3': 'plate_hole'}
    benchmark = benchmark_map.get(choice, 'cantilever')
    if choice not in benchmark_map:
        print("Invalid choice, defaulting to cantilever.")

    l_bracket_fillet_init = 0.15 if (benchmark == 'l_bracket' and post in ('I', 'B')) else None

    # 1. Train
    model, trainer, sampler, physics = train_forward_solver(
        benchmark=benchmark,
        device=device,
        epochs=11000,       # increase to 10000–15000 for final paper runs
        print_every=500,
        l_bracket_fillet_init=l_bracket_fillet_init,
    )

    # 2. Optional validation
    if post in ('V', 'B'):
        run_validation(
            model=model,
            sampler=sampler,
            physics=physics,
            benchmark=benchmark,
            device=device,
            use_mock=True   # change to False once you have real FEM .npy files
        )
        os.makedirs(str(RESULTS_DIR), exist_ok=True)
        plot_fem_comparison(
            model, sampler, physics, benchmark=benchmark,
            use_mock=True,  # keep in sync with run_validation's use_mock above
            save_path=str(RESULTS_DIR / f'{benchmark}_fem_comparison.png')
        )

    # 3. Optional inverse design
    if post in ('I', 'B'):
        if benchmark == 'plate_hole':
            run_inverse_design_on_plate(
                model, sampler, physics, device,
                n_outer=12, n_inner=300
            )
        elif benchmark == 'l_bracket':
            run_inverse_design_on_l_bracket(
                model, sampler, physics, device,
                n_outer=12, n_inner=300
            )
        else:
            print("\n[Info] Inverse design isn't available for the cantilever "
                  "benchmark - there's no shape parameter to optimize there "
                  "(fixed length/height, not a hole or fillet).")

    # 4. Plots
    visualize_results(model, sampler, physics, trainer, benchmark)

    print()
    print("Done. Check the results/ folder.")
    print("=" * 70)


if __name__ == "__main__":
    main()