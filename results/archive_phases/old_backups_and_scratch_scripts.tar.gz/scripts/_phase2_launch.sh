#!/usr/bin/env bash
# Detached Phase-2 screen launcher. Spawns _phase2_screen.sh via setsid so the
# chained benchmark runs survive this shell closing.
set -u
cd /home/sultra/atlas_main
mkdir -p results/phase2/lbfgs results/phase2/driver
echo "LAUNCH_TS $(date '+%Y-%m-%d %H:%M:%S')"
setsid bash scripts/_phase2_screen.sh phase2 2000 100 "l_bracket plate_hole" \
    >> results/phase2/driver/screen.log 2>&1 < /dev/null &
echo "SCREEN_SPAWNED pid=$!"
sleep 2
cat results/phase2/driver/screen.log 2>/dev/null | tail -2
