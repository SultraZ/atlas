#!/usr/bin/env bash
# Detached Phase-3 Kirsch screen launcher. Spawns _phase3_screen.sh via setsid
# so the run survives this shell closing.
set -u
cd /home/sultra/atlas_main
mkdir -p results/phase3/kirsch results/phase3/driver
echo "LAUNCH_TS $(date '+%Y-%m-%d %H:%M:%S')"
setsid bash scripts/_phase3_screen.sh phase3 2000 \
    >> results/phase3/driver/screen.log 2>&1 < /dev/null &
echo "SCREEN_SPAWNED pid=$!"
sleep 2
cat results/phase3/driver/screen.log 2>/dev/null | tail -2