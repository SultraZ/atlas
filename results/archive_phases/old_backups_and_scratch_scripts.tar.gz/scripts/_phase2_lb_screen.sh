#!/usr/bin/env bash
set -u
cd /home/sultra/atlas_main
export PYTHONUNBUFFERED=1
PY=/home/sultra/miniconda3/envs/Atlas/bin/python
EPOCHS=${EPOCHS:-2000}
ADAPT_EVERY=${ADAPT_EVERY:-100}
LOG=results/phase2/lbfgs/l_bracket_screen.log
mkdir -p results/phase2/lbfgs

echo "==== $(date '+%Y-%m-%d %H:%M:%S') :: PHASE2 lbfgs+adaptive-weights screen :: l_bracket (epochs=$EPOCHS adapt_every=$ADAPT_EVERY) ===="
timeout 2400 $PY tests/validate_all_benchmarks.py --benchmark l_bracket \
  --epochs "$EPOCHS" --lbfgs --adaptive-weights --adapt-every "$ADAPT_EVERY" "$@" \
  > "$LOG" 2>&1
echo "rc=$?"
echo "PHASE2_LB_SCREEN_DONE $(date '+%Y-%m-%d %H:%M:%S')"
