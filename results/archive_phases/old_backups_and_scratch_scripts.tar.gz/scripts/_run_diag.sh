#!/bin/bash
set -u
export PYTHONUNBUFFERED=1
PY=/home/sultra/miniconda3/envs/Atlas/bin/python
cd /home/sultra/atlas_main
$PY scripts/_diag_phase4.py
echo "DIAG_RC=$?"