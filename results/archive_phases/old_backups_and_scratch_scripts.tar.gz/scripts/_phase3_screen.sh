#!/usr/bin/env bash
# Phase-3 Kirsch warm-start screen driver (runs detached under `screen`).
# args: PHASE EPOCHS
set -u
cd /home/sultra/atlas_main
export PYTHONUNBUFFERED=1
PY=/home/sultra/miniconda3/envs/Atlas/bin/python
PHASE=${1:-phase3}
EPOCHS=${2:-2000}
BENCH=plate_hole
LOGSDIR=results/$PHASE/kirsch
mkdir -p "$LOGSDIR"

LOG="$LOGSDIR/${BENCH}_screen.log"
echo "================ $(date '+%Y-%m-%d %H:%M:%S') :: $PHASE :: warm-kirsch+lbfgs :: $BENCH (epochs=$EPOCHS) ================"
timeout 3400 "$PY" tests/validate_all_benchmarks.py --benchmark "$BENCH" \
    --epochs "$EPOCHS" --lbfgs --warm-kirsch --no-plots \
    > "$LOG" 2>&1
echo "rc=$? $PHASE $BENCH"
# Snapshot artifacts (no-plots mode writes validation.json + model.pt).
for f in validation.json model.pt convergence.png fem_comparison.png displacement.png stress.png deformed.png; do
  if [ -f "results/${BENCH}_${f}" ]; then
    cp "results/${BENCH}_${f}" "$LOGSDIR/${BENCH}_${f}"
  fi
done
echo "SNAPSHOT done $PHASE $BENCH"
echo "PHASE3_SCREEN_DONE $(date '+%Y-%m-%d %H:%M:%S')"