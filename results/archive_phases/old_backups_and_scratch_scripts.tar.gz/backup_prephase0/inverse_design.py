"""
inverse_design.py - Parametric Shape Optimization using Automatic Differentiation
Optimizes geometric parameters (e.g., hole radius) through differentiable XPINN solver
"""

import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass


@dataclass
class InverseDesignConfig:
    """Configuration for inverse design optimization"""
    initial_radius: float = 0.3
    target_compliance: Optional[float] = None
    max_radius: float = 0.8
    min_radius: float = 0.1
    lr_geometry: float = 1e-3
    lr_network: float = 1e-3
    n_outer_iterations: int = 50
    n_inner_iterations: int = 500
    

class ComplianceObjective:
    """
    Structural Compliance Objective Function

    Compliance C = ∫ (f · u) dΩ + ∫ (t · u) dΓ

    For a structure, minimizing compliance is equivalent to maximizing stiffness.
    Lower compliance = stiffer structure = less displacement under load.

    # TODO(compliance target): the paper-grade acceptance criterion for the
    # inverse-design module is "compliance within <= 10% of a reference"
    # (Jeong et al., 2023 tolerance). That target is NOT yet implemented as a
    # PASS/FAIL gate here because the inverse-design module's reference
    # compliance comparison isn't active (see also the provisional von Mises
    # target in validation.py VON_MISES_EXCL_TARGET). Wire this gate in when
    # the inverse-design compliance reporting lands; the 10% value there is
    # the same provisional-by-analogy value - revisit against real runs.
    """
    
    def __init__(self, physics):
        """
        Args:
            physics: PlaneStressElasticity instance
        """
        self.physics = physics
    
    def compute(
        self,
        network: nn.Module,
        x: torch.Tensor,
        y: torch.Tensor,
        t_x: torch.Tensor,
        t_y: torch.Tensor,
        weights: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Compute compliance approximation using collocation points
        
        C ≈ Σ (t_x · u + t_y · v) * w
        
        Args:
            network: Neural network predicting displacements
            x, y: Collocation point coordinates
            t_x, t_y: Applied traction at collocation points
            weights: Integration weights (optional)
            
        Returns:
            Compliance value (scalar tensor)
        """
        coords = torch.cat([x, y], dim=1)
        uv = network(coords)
        u, v = uv[:, 0:1], uv[:, 1:2]
        
        # Work done by external forces
        work = t_x * u + t_y * v
        
        if weights is not None:
            compliance = torch.sum(work * weights)
        else:
            compliance = torch.mean(work) * x.shape[0]  # Scale by number of points
        
        return compliance


class InverseDesignOptimizer:
    """
    Inverse Shape Design using Differentiable XPINN - generalized to drive
    ANY single scalar geometric parameter that a sampler exposes as a
    trainable tensor (currently: PlateWithHoleSampler.r, or
    LBracketSampler.fillet when fillet_init was set). See __init__ for how
    a benchmark plugs itself in via design_param/resample_fn/sensitivity_fn
    rather than this class hardcoding "radius"/"plate" anywhere.

    Approach:
        1. Trainable geometric parameter (design_param) drives collocation
           point positions in a differentiable way
        2. Train XPINN to solve forward problem for the current geometry
        3. Compute a differentiable sensitivity objective (sensitivity_fn)
        4. Backpropagate to get its gradient w.r.t. design_param
        5. Update design_param to (heuristically) reduce that objective
    """
    
    def __init__(
        self,
        xpinn_model,
        physics,
        sampler,
        config: InverseDesignConfig,
        design_param: torch.Tensor,
        resample_fn,
        sensitivity_fn,
        param_name: str = "parameter",
    ):
        """
        Args:
            xpinn_model: XPINN model instance
            physics: PlaneStressElasticity instance (should match whatever
                the model was actually trained against - e.g. the scaled
                physics_train if non-dimensionalization was used)
            sampler: the sampler owning design_param (kept for reference/
                history access, e.g. sampler.W/H in diagnostics)
            config: optimization configuration (min_radius/max_radius are
                used as generic bounds regardless of what design_param
                conceptually represents)
            design_param: the trainable geometry tensor being optimized -
                MUST be the exact same tensor object the sampler's own
                sample_* methods read from (e.g. sampler.r or
                sampler.fillet), so resample_fn() picks up updates to it
            resample_fn: zero-arg callable returning
                (subdomain_data, interface_data, boundary_data) for the
                CURRENT geometry. Kept as a callback (rather than this
                class calling sampler.sample_boundary(...) directly)
                because different benchmarks' sample_boundary() take
                different keyword args (P= vs sigma_inf=) - the caller
                bakes in whichever one applies via a closure.
            sensitivity_fn: zero-arg callable returning a scalar tensor
                differentiable w.r.t. design_param (e.g.
                hole_region_sensitivity_objective or
                fillet_region_sensitivity_objective below - see their
                docstrings for what they do and don't guarantee).
            param_name: only used for print/plot labels.
        """
        self.model = xpinn_model
        self.physics = physics
        self.sampler = sampler
        self.config = config
        self.design_param = design_param
        self.resample_fn = resample_fn
        self.sensitivity_fn = sensitivity_fn
        self.param_name = param_name
        
        # Geometry optimizer (for design_param)
        self.geom_optimizer = torch.optim.Adam(
            [design_param],
            lr=config.lr_geometry
        )
        
        # Network optimizer
        self.net_optimizer = torch.optim.Adam(
            xpinn_model.parameters(),
            lr=config.lr_network
        )
        
        # History tracking. Keys kept as 'radius'/'compliance' (rather than
        # renamed to something generic) for backward compatibility with
        # plot_history() and any external code already reading .history -
        # they now generically mean "design_param value" / "sensitivity
        # objective value" regardless of which benchmark this is.
        self.history = {
            'radius': [],
            'compliance': [],
            'loss': []
        }
    
    def forward_solve_step(
        self,
        subdomain_data: List[Dict],
        interface_data: List[Dict],
        boundary_data: List[Dict],
        loss_fn
    ) -> float:
        """
        One step of forward XPINN solve
        
        Returns:
            Total loss value
        """
        self.net_optimizer.zero_grad()
        
        total_loss, _ = loss_fn.compute_total_loss(
            self.model, subdomain_data, interface_data, boundary_data
        )
        
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
        self.net_optimizer.step()
        
        return total_loss.item()
    
    def geometry_update_step(self) -> Tuple[float, float]:
        """
        Update design_param based on sensitivity_fn's gradient.
        
        Returns:
            (objective_value, new_design_param_value)
        """
        self.geom_optimizer.zero_grad()

        objective = self.sensitivity_fn()

        # Backpropagate to get gradient w.r.t. design_param. Whatever
        # subdomain network sensitivity_fn evaluates through also picks up
        # a .grad here, but since we never call self.net_optimizer.step()
        # in this method, that's harmless - only design_param gets updated.
        objective.backward()

        if self.design_param.grad is not None:
            print(f"  {self.param_name} gradient: {self.design_param.grad.item():.6e}")
            self.geom_optimizer.step()
            with torch.no_grad():
                self.design_param.clamp_(
                    self.config.min_radius,
                    self.config.max_radius
                )
        else:
            print(f"  [Warning] {self.param_name}.grad is None - it did not update this iteration.")

        return objective.item(), self.design_param.item()
    
    def optimize(
        self,
        loss_fn,
        verbose: bool = True
    ):
        """
        Main inverse design optimization loop
        
        Uses nested optimization:
        - Outer loop: Update geometry (design_param)
        - Inner loop: Solve forward problem (train XPINN)
        
        Args:
            loss_fn: XPINNLoss instance
            verbose: Print progress
        """
        print("=" * 70)
        print("INVERSE SHAPE DESIGN OPTIMIZATION")
        print("=" * 70)
        print(f"Initial {self.param_name}: {self.design_param.item():.4f}")
        print(f"{self.param_name} bounds: [{self.config.min_radius}, {self.config.max_radius}]")
        print()
        
        for outer_iter in range(self.config.n_outer_iterations):
            if verbose:
                print(f"Outer Iteration {outer_iter + 1}/{self.config.n_outer_iterations}")
                print(f"  Current {self.param_name}: {self.design_param.item():.4f}")
            
            # Re-sample collocation points for current geometry
            subdomain_data, interface_data, boundary_data = self.resample_fn()
            
            # Inner loop: Solve forward problem
            for inner_iter in range(self.config.n_inner_iterations):
                loss = self.forward_solve_step(
                    subdomain_data, interface_data, boundary_data, loss_fn
                )
                
                if (inner_iter + 1) % 100 == 0 and verbose:
                    print(f"    Inner iter {inner_iter + 1}: Loss = {loss:.6e}")
            
            self.history['loss'].append(loss)
            
            # Geometry update
            objective_val, new_val = self.geometry_update_step()
            
            self.history['radius'].append(new_val)
            self.history['compliance'].append(objective_val)
            
            if verbose:
                print(f"  Objective (sensitivity proxy): {objective_val:.6e}")
                print(f"  New {self.param_name}: {new_val:.4f}")
                print()
        
        print("=" * 70)
        print("OPTIMIZATION COMPLETE")
        print(f"Final {self.param_name}: {self.design_param.item():.4f}")
        print(f"Final objective: {self.history['compliance'][-1]:.6e}")
        print("=" * 70)
    
    def plot_history(self, save_path: Optional[str] = None):
        """Plot optimization history"""
        fig, axes = plt.subplots(1, 3, figsize=(15, 4))
        
        label = self.param_name.capitalize()

        # Design parameter evolution
        axes[0].plot(self.history['radius'], 'b-o', markersize=4)
        axes[0].set_xlabel('Outer Iteration')
        axes[0].set_ylabel(label)
        axes[0].set_title(f'{label} Evolution')
        axes[0].grid(True, alpha=0.3)
        
        # Objective evolution
        axes[1].semilogy(self.history['compliance'], 'r-o', markersize=4)
        axes[1].set_xlabel('Outer Iteration')
        axes[1].set_ylabel('Sensitivity Objective')
        axes[1].set_title('Objective Evolution')
        axes[1].grid(True, alpha=0.3)
        
        # Loss evolution
        axes[2].semilogy(self.history['loss'], 'g-', linewidth=0.5)
        axes[2].set_xlabel('Outer Iteration')
        axes[2].set_ylabel('XPINN Loss')
        axes[2].set_title('Forward Solve Loss')
        axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
        plt.close(fig)


def compute_compliance_for_loaded_boundary(
    model, sampler, sigma_inf: float = 1e6
) -> torch.Tensor:
    """
    Compute compliance on the loaded (right, x=W) boundary of a
    PlateWithHoleSampler problem.

    Kept for reference / diagnostics only - DO NOT use this as an inverse-
    design sensitivity_fn: x=W, y in [0,H] never depends on the hole radius
    r, so this graph never touches r and .backward() leaves r.grad as None
    forever - the radius would silently never update. See
    hole_region_sensitivity_objective for the function actually used.
    """
    compliance_fn = ComplianceObjective(None)
    n_pts = 100
    y = torch.linspace(0, sampler.H, n_pts, device=sampler.device).reshape(-1, 1)
    x = torch.full_like(y, sampler.W)
    t_x = torch.full_like(x, sigma_inf)
    t_y = torch.zeros_like(x)
    network = model.get_subdomain_network(2)  # far-field network
    return compliance_fn.compute(network, x, y, t_x, t_y)


def hole_region_sensitivity_objective(model, physics, sampler,
                                      delta: float = 0.05, n_theta: int = 100) -> torch.Tensor:
    """
    Differentiable proxy objective for PlateWithHoleSampler's outer
    (geometry) loop.

    compute_compliance_for_loaded_boundary above never depends on r, so
    r.grad was always None and the radius never moved (see its docstring).
    This objective instead evaluates the elastic strain energy density with
    the *already-trained, now-frozen* near-hole network (subdomain 0), on a
    ring of points a small offset `delta` outside the hole boundary. Those
    points are generated with sample_hole_boundary_differentiable(), i.e.
    as an explicit differentiable function of r, so d(objective)/dr is
    well-defined and sampler.r.grad is populated by objective.backward().

    This is a pragmatic proxy for "reduce stress concentration around the
    hole as a function of its size" - it is NOT a rigorously-derived
    continuum shape derivative of the structural compliance (that would
    need the classical Hadamard/Céa adjoint formulation, which is a
    research-level derivation beyond a code-review fix). Treat the sign
    and magnitude of sampler.r.grad as a heuristic descent direction, and
    validate against a finite-difference check before trusting it for a
    paper-quality result.
    """
    x_hole, y_hole = sampler.sample_hole_boundary_differentiable(n_theta=n_theta)

    # Evaluate a ring offset outward from the hole (traction there is
    # zero by BC, so the hole boundary itself carries no strain-energy
    # signal - the concentration lives just outside it).
    theta = torch.atan2(y_hole, x_hole)
    rho = sampler.r + delta
    x = (rho * torch.cos(theta)).requires_grad_(True)
    y = (rho * torch.sin(theta)).requires_grad_(True)

    network = model.get_subdomain_network(0)
    coords = torch.cat([x, y], dim=1)
    uv = network(coords)
    u, v = uv[:, 0:1], uv[:, 1:2]

    eps_xx, eps_yy, eps_xy = physics.compute_strains(u, v, x, y)
    sig_xx, sig_yy, sig_xy = physics.compute_stresses(eps_xx, eps_yy, eps_xy)
    energy_density = 0.5 * (sig_xx * eps_xx + sig_yy * eps_yy + 2 * sig_xy * eps_xy)

    # Normalize to O(1). The network runs in the SCALED physics/output space
    # (E_train ~ O(1), outputs ~ u_s ~ 1e-5), so the raw strain-energy
    # density here is ~1e-10 and its derivative w.r.t. r is ~1e-12 - far
    # below the Adam step for lr_geometry=1e-3, which is exactly why the
    # radius appeared frozen (gradient printed but no motion). Dividing by a
    # detached magnitude is a strictly positive rescaling of the objective,
    # so the descent DIRECTION is unchanged while the gradient becomes O(1)
    # and lr_geometry actually moves r. (Same root cause as bug-fix #7's
    # raw-SI scaling, applied to the inverse-design objective.)
    scale = energy_density.detach().abs().mean() + 1e-12
    return torch.mean(energy_density) / scale


def fillet_region_sensitivity_objective(model, physics, sampler,
                                        delta: float = 0.05, n_theta: int = 60) -> torch.Tensor:
    """
    Differentiable proxy objective for LBracketSampler's outer (geometry)
    loop, when fillet_init was set - the exact same idea and the exact same
    caveats as hole_region_sensitivity_objective above (pragmatic strain-
    energy proxy, not a rigorous shape derivative - validate with a
    finite-difference check before trusting it for a paper result), just
    applied to the fillet arc instead of the hole boundary.

    Evaluates strain energy on a ring offset `delta` radially outward
    (away from the fillet's own center C) from the fillet arc, using
    subdomain 0's network (the fillet patch was assigned to sub0 - see
    LBracketSampler's class docstring). The offset point positions depend
    on the fillet both through the arc's radius AND through its center C
    (which itself moves as C=(s-fillet, s+fillet)), so this captures more
    than a naive "just grow the radius" sensitivity.
    """
    x_arc, y_arc = sampler.sample_fillet_arc_differentiable(n_theta=n_theta)
    Cx, Cy = sampler._fillet_center()
    theta = torch.atan2(y_arc - Cy, x_arc - Cx)
    rho = sampler.fillet + delta
    x = (Cx + rho * torch.cos(theta)).requires_grad_(True)
    y = (Cy + rho * torch.sin(theta)).requires_grad_(True)

    network = model.get_subdomain_network(0)  # fillet patch belongs to sub0
    coords = torch.cat([x, y], dim=1)
    uv = network(coords)
    u, v = uv[:, 0:1], uv[:, 1:2]

    eps_xx, eps_yy, eps_xy = physics.compute_strains(u, v, x, y)
    sig_xx, sig_yy, sig_xy = physics.compute_stresses(eps_xx, eps_yy, eps_xy)
    energy_density = 0.5 * (sig_xx * eps_xx + sig_yy * eps_yy + 2 * sig_xy * eps_xy)

    # Same O(1) normalization as hole_region_sensitivity_objective - the
    # scaled-network strain energy (~1e-10) otherwise makes d(Objective)/d
    # (fillet) ~1e-12, far below lr_geometry, and the fillet never moves.
    scale = energy_density.detach().abs().mean() + 1e-12
    return torch.mean(energy_density) / scale


def differentiable_hole_boundary_sampling(
    r: torch.Tensor,
    n_theta: int = 100,
    device: str = 'cpu'
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Generate hole boundary points as differentiable function of radius
    
    This is key for inverse design: the boundary points must depend
    on r in a differentiable way for autograd to work.
    
    Args:
        r: Trainable radius tensor (scalar with requires_grad=True)
        n_theta: Number of angular samples
        device: Compute device
        
    Returns:
        x, y: Boundary point coordinates (differentiable w.r.t. r)
    """
    # Angles (fixed, not trainable)
    theta = torch.linspace(0, np.pi/2, n_theta, device=device)
    
    # Boundary points (differentiable w.r.t. r)
    x = r * torch.cos(theta)
    y = r * torch.sin(theta)
    
    return x.reshape(-1, 1), y.reshape(-1, 1)


class ComplianceSensitivity:
    """
    Compute sensitivity of compliance with respect to design parameters
    using adjoint method or direct differentiation.
    """
    
    @staticmethod
    def compute_shape_sensitivity(
        compliance: torch.Tensor,
        design_params: List[torch.Tensor]
    ) -> List[torch.Tensor]:
        """
        Compute ∂C/∂p for each design parameter p
        
        Args:
            compliance: Compliance objective (scalar tensor)
            design_params: List of trainable geometric parameters
            
        Returns:
            List of gradient tensors
        """
        sensitivities = torch.autograd.grad(
            compliance,
            design_params,
            create_graph=False,
            allow_unused=True
        )
        
        return list(sensitivities)


# Example usage in main training script:
"""
from atlas.inverse_design import InverseDesignOptimizer, InverseDesignConfig
from atlas.sampling import PlateWithHoleSampler
from atlas.networks import XPINNModel
from atlas.physics import PlaneStressElasticity
from atlas.loss_functions import XPINNLoss

# Setup
device = 'cuda' if torch.cuda.is_available() else 'cpu'
physics = PlaneStressElasticity(E=210e9, nu=0.3)

# Create sampler with trainable radius
sampler = PlateWithHoleSampler(
    W=2.0, H=2.0, r_init=0.3,
    n_interior=500, device=device
)

# Create XPINN model
model = XPINNModel(num_subdomains=3, device=device)

# Create loss function
loss_fn = XPINNLoss(physics)

# Configure inverse design
config = InverseDesignConfig(
    initial_radius=0.3,
    min_radius=0.1,
    max_radius=0.8,
    n_outer_iterations=20,
    n_inner_iterations=200
)

# Run optimization
optimizer = InverseDesignOptimizer(model, physics, sampler, config)
optimizer.optimize(loss_fn, sigma_inf=1e6)

# Plot results
optimizer.plot_history('inverse_design_history.png')
"""
