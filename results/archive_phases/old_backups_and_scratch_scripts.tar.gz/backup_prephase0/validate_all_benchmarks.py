"""Per-benchmark validation reporting driver (Phase A).

Trains each forward benchmark with its best-known recipe (fully unsupervised -
no FEM-derived labels/anchoring anywhere), validates against the real FEM
reference through validation.py - which now also reports the global + excluded
(von_mises_l2_excl, auto r_excl) von Mises L2 metrics - and writes the
per-benchmark artifacts to results/:

    {benchmark}_validation.json      full metrics dict (incl. new keys)
    {benchmark}_model.pt             trained weights (snapshot)
    {benchmark}_fem_comparison.png   ATLAS-vs-FEM displacement + stress
    {benchmark}_displacement.png
    {benchmark}_stress.png
    {benchmark}_deformed.png
    {benchmark}_convergence.png

Recipes: cantilever uses the warm EB/Timoshenko prefit + Adam-only path;
l_bracket and plate_hole have no closed-form reference field and run the
regular baseline (their honest results reflect that).

Usage:
    python tests/validate_all_benchmarks.py                 # all three
    python tests/validate_all_benchmarks.py --benchmark cantilever
    python tests/validate_all_benchmarks.py --epochs 5000
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import torch

from atlas.atlas_main import train_forward_solver
from atlas.validation import run_validation
from atlas.visualization import (plot_fem_comparison, plot_displacement_field,
                                 plot_von_mises_stress, plot_deformed_shape,
                                 plot_training_convergence)
from atlas.paths import RESULTS_DIR, FEM_REFERENCE_DIR

BENCHMARKS = ['cantilever', 'l_bracket', 'plate_hole']

# Best-known forward recipes. No labeled data anywhere - the cantilever's
# "warm start" is the closed-form Euler-Bernoulli/Timoshenko beam solution
# (physics), not FEM.
BENCH_DEFAULTS = {
    'cantilever': dict(epochs=11000, warm_start_eb=True, prefit_epochs=6000, use_lbfgs=False),
    'l_bracket':   dict(epochs=5000, use_lbfgs=False),
    'plate_hole':  dict(epochs=5000, use_lbfgs=False),
}


def train_and_report(benchmark: str, device: str, epoch_override):
    print("\n" + "=" * 72)
    print(f"BENCHMARK: {benchmark.upper()}  (device={device}, seed=42)")
    print("=" * 72)

    torch.manual_seed(42)
    np.random.seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)

    cfg = dict(BENCH_DEFAULTS[benchmark])
    if epoch_override is not None:
        cfg['epochs'] = epoch_override

    model, trainer, sampler, phys_real = train_forward_solver(
        benchmark=benchmark, device=device, **cfg)

    os.makedirs(str(RESULTS_DIR), exist_ok=True)
    torch.save(model.state_dict(), str(RESULTS_DIR / f"{benchmark}_model.pt"))

    res = run_validation(
        model=model, sampler=sampler, physics=phys_real,
        benchmark=benchmark, device=device,
        use_mock=False, data_dir=str(FEM_REFERENCE_DIR),  # r_excl defaults to auto
    )
    res['benchmark'] = benchmark
    res['device'] = device
    res['seed'] = 42
    with open(str(RESULTS_DIR / f"{benchmark}_validation.json"), "w") as f:
        json.dump(res, f, indent=2)

    plot_fem_comparison(model, sampler, phys_real, benchmark=benchmark,
                        use_mock=False, data_dir=str(FEM_REFERENCE_DIR),
                        save_path=str(RESULTS_DIR / f"{benchmark}_fem_comparison.png"))
    plot_displacement_field(model, sampler, phys_real, n_grid=90,
                            save_path=str(RESULTS_DIR / f"{benchmark}_displacement.png"))
    plot_von_mises_stress(model, sampler, phys_real, n_grid=90,
                          save_path=str(RESULTS_DIR / f"{benchmark}_stress.png"))
    plot_deformed_shape(model, sampler, n_grid=50,
                        save_path=str(RESULTS_DIR / f"{benchmark}_deformed.png"))
    plot_training_convergence(
        trainer.history,
        save_path=str(RESULTS_DIR / f"{benchmark}_convergence.png"),
        adam_epoch_count=trainer.adam_epoch_count,
    )

    print("\n--- {} validation summary ---".format(benchmark))
    for k in ('relative_L2_u', 'relative_L2_v', 'relative_L2_displacement',
              'displacement_within_5pct_target', 'relative_L2_von_mises',
              'von_mises_l2_excl', 'von_mises_exclusion_radius',
              'von_mises_l2_excl_within_10pct'):
        print(f"  {k}: {res.get(k)}")
    return res


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--benchmark', default=None,
                        choices=BENCHMARKS, help='Run one benchmark (default: all).')
    parser.add_argument('--device', default=None, help='cuda/cpu (default: cuda if available).')
    parser.add_argument('--epochs', type=int, default=None,
                        help='Override the epoch budget for the chosen run(s).')
    args = parser.parse_args()

    device = args.device or ('cuda' if torch.cuda.is_available() else 'cpu')
    targets = [args.benchmark] if args.benchmark else BENCHMARKS
    all_results = {}
    for bench in targets:
        all_results[bench] = train_and_report(bench, device, args.epochs)

    print("\n" + "=" * 72)
    print("ALL-BENCHMARK SUMMARY")
    print("=" * 72)
    for bench, res in all_results.items():
        disp = res.get('relative_L2_displacement')
        disp_ok = res.get('displacement_within_5pct_target')
        vm_excl = res.get('von_mises_l2_excl')
        vm_ok = res.get('von_mises_l2_excl_within_10pct')
        print(f"  {bench:12s} |disp| L2 {disp:.2%}  [5% target {'PASS' if disp_ok else 'FAIL'}]  | "
              f"von Mises excl {vm_excl if vm_excl is None else f'{vm_excl:.2%}'}  "
              f"[10% {'PASS' if vm_ok else 'FAIL'}]")
    print("\nArtifacts written under", RESULTS_DIR)


if __name__ == '__main__':
    main()