"""Phase-4 pre-flight smoke (throwaway): exercises the MPE wiring end to end
at tiny budget. Checks, in order:
  1. All edited modules import cleanly.
  2. The MPE monolith forward respects the hard rollers EXACTLY.
  3. The energy objective stays finite and DESCENDS over ~50 Adam steps.
  4. Strain/work scales are sane (~u_s^2 E energy, negative-converging PI).
  5. The additive ROI metric computes (numbers consistent with hand count).
  6. FEMValidator on mock data still produces all keys incl. the new ROI key.
"""
import numpy as np
import torch
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from atlas.networks import create_xpinn_for_benchmark, default_fourier_freqs
from atlas.sampling import PlateWithHoleSampler
from atlas.atlas_main import (_plate_hole_essential_mask,
                              _plate_hole_energy_context, train_forward_solver)
from atlas.validation import compute_von_mises_roi_metric, run_validation

DEVICE = 'cpu'
print("== 1. imports OK ==")

torch.manual_seed(42)
np.random.seed(42)

print("== 2. rollers exact ==")
sampler = PlateWithHoleSampler(W=2.0, H=2.0, r_init=0.3, device=DEVICE)
u_s = (1e6 * sampler.W) / 210e9
model = create_xpinn_for_benchmark(
    'plate_hole', hidden_layers=2, neurons=16, device=DEVICE,
    output_scale=u_s, monolith=True,
    essential_mask=_plate_hole_essential_mask,
    fourier_freqs=default_fourier_freqs(sampler.W, n_freqs=4),
)
# u vanishes on x=0 face, v vanishes on y=0 face (any sample row).
net0 = model.get_subdomain_network(0)
xx0 = torch.zeros(64, 1, dtype=torch.float32)
yy = torch.linspace(0.0, 2.0, 64).reshape(-1, 1)
uv0 = net0(torch.cat([xx0, yy], dim=1))
assert torch.allclose(uv0[:, 0:1], torch.zeros_like(uv0[:, 0:1])), "u not zero on x=0"
assert torch.allclose(uv0[:, 1:2], uv0[:, 1:2]), "v should be free on x=0"
xs = torch.linspace(0.3, 2.0, 64).reshape(-1, 1)
yy0 = torch.zeros(64, 1, dtype=torch.float32)
uv1 = net0(torch.cat([xs, yy0], dim=1))
assert torch.allclose(uv1[:, 1:2], torch.zeros_like(uv1[:, 1:2])), "v not zero on y=0"
print("   u(0,y)=0 and v(x,0)=0 EXACT  -> OK")

print("== 3. energy finite + descending over 50 Adam steps ==")
from atlas.physics import PlaneStressElasticity
physics_train = PlaneStressElasticity(E=210e9 / 1e11, nu=0.3)
from atlas.loss_functions import XPINNLoss
sigma_inf = 1e6 / 1e11
interior, loaded = _plate_hole_energy_context(sampler, sigma_inf, DEVICE, n_points=1200)
scales = {'energy': 0.5 * (physics_train.E * u_s) * (u_s / 2.0)}
loss_fn = XPINNLoss(physics_train, weights={'pde': 0, 'dirichlet': 0, 'neumann': 0,
                                            'interface_u': 0, 'interface_t': 0},
                    scales=scales)
loss_fn.energy_context = (interior, loaded)
assert model.monolith, "MPE requires a monolith"
optim = torch.optim.Adam(model.parameters(), lr=1e-3)
prev = None
vals = []
for ep in range(50):
    optim.zero_grad()
    net_all = model.get_subdomain_network(0)
    pi = loss_fn.energy_loss(net_all, interior, loaded)
    pi.backward()
    optim.step()
    v = float(pi.item())
    vals.append(v)
    assert np.isfinite(v), f"PI diverged at epoch {ep}: {v}"
    if prev is not None:
        assert v <= prev + 1e-5 * max(1.0, abs(prev)), (
            f"PI not descending at epoch {ep}: {prev:.6e} -> {v:.6e}")
    prev = v
strain_i = float(loss_fn.energy_loss(net_all, interior, [{
    'x': torch.tensor([[2.0]], dtype=torch.float32),
    'y': torch.tensor([[0.0]], dtype=torch.float32),
    't_x': torch.tensor([[0.0]], dtype=torch.float32),
    't_y': torch.tensor([[0.0]], dtype=torch.float32),
    'length': 1.0}]))
print(f"   PI: {vals[0]:.6e} -> {vals[-1]:.6e} (monotone non-increasing, finite) -> OK")
print(f"   strain-energy-only reading (no work) ~ {strain_i:.6e}")

print("== 4. quick sanity estimate ==")
area_total = sum(c['area'] for c in interior)
eps_s = u_s / 2.0
e_scale = 0.5 * physics_train.E * eps_s ** 2 * area_total
print(f"   total area ~ {area_total:.4f}; characteristic strain energy ~ {e_scale:.3e}")

print("== 5. ROI metric on synthetic arrays ==")
rng = np.random.default_rng(0)
coords = np.column_stack([rng.uniform(0, 2, 20000), rng.uniform(0, 2, 20000)])
vm_pred = rng.random(20000)
vm_fem = rng.random(20000)
geom = {'r': 0.3, 'W': 2.0, 'H': 2.0}
roi = compute_von_mises_roi_metric(vm_pred, vm_fem, coords, 'plate_hole', geom)
frac_band = float(np.mean(np.abs(np.hypot(coords[:, 0], coords[:, 1]) - 0.3) < 0.06))
assert roi['von_mises_l2_roi'] is not None
print(f"   ring band excludes {roi['von_mises_roi_excluded_points']}/20000 "
      f"(expected ~{frac_band:.3%}) -> OK")
# no-crash on unconfigured / degenerate
print("   cantilever ROI:", compute_von_mises_roi_metric(
    vm_pred, vm_fem, coords, 'cantilever', {'H': 1.0})['von_mises_l2_roi'])

print("== 6. FEMValidator smoke on mock ==")
train_env = train_forward_solver('plate_hole', device=DEVICE, epochs=3,
                                 print_every=100000, n_interior=90, n_boundary=40,
                                 n_interface=20, use_lbfgs=False, use_mpe=True,
                                 hidden_layers=2, neurons=16)
model2, trainer2, sampler2, phys2 = train_env
res = run_validation(model2, sampler2, phys2, 'plate_hole', device=DEVICE, use_mock=True)
for k in ('relative_L2_displacement', 'von_mises_l2_roi', 'von_mises_l2_roi_within_10pct',
          'von_mises_roi_desc', 'von_mises_roi_excluded_points'):
    assert k in res, f"missing key {k}"
print("   validation.json keys include ROI metric -> OK")
print("\nSMOKE PASSED")