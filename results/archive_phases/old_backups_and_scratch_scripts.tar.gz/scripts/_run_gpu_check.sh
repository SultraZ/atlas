#!/bin/bash
set -u
export PYTHONUNBUFFERED=1
PY=/home/sultra/miniconda3/envs/Atlas/bin/python
cd /home/sultra/atlas_main
$PY scripts/_gpu_mpe_check.py
echo "GPU_MAT_RC=$?"