"""Throwaway diagnostic: dissect the Phase-4 MPE gate result."""
import os
import sys
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from atlas.atlas_main import _plate_hole_energy_context, _plate_hole_essential_mask
from atlas.networks import create_xpinn_for_benchmark, default_fourier_freqs
from atlas.physics import PlaneStressElasticity
from atlas.loss_functions import XPINNLoss
from atlas.paths import RESULTS_DIR, FEM_REFERENCE_DIR
from atlas.validation import (singular_locations, default_exclusion_radius,
                              compute_von_mises_metrics)
from atlas.sampling import PlateWithHoleSampler

OUT = str(RESULTS_DIR / 'phase4' / 'mpe')

sampler = PlateWithHoleSampler(W=2.0, H=2.0, r_init=0.3, device='cpu')
u_s = (1e6 * sampler.W) / 210e9
model = create_xpinn_for_benchmark(
    'plate_hole', hidden_layers=4, neurons=64, device='cpu',
    output_scale=u_s, monolith=True,
    essential_mask=_plate_hole_essential_mask,
    fourier_freqs=default_fourier_freqs(sampler.W),
)
state = torch.load(OUT + '/plate_hole_model.pt', map_location='cpu')
model.load_state_dict(state)
net = model.get_subdomain_network(0)

coords = np.load(os.path.join(FEM_REFERENCE_DIR, 'plate_hole_coords.npy')).reshape(-1, 2)
u_ref = np.load(os.path.join(FEM_REFERENCE_DIR, 'plate_hole_u.npy')).reshape(-1)
v_ref = np.load(os.path.join(FEM_REFERENCE_DIR, 'plate_hole_v.npy')).reshape(-1)
vm_ref = np.load(os.path.join(FEM_REFERENCE_DIR, 'plate_hole_vonmises.npy')).reshape(-1)
print("ref umax|vmax:", np.max(np.abs(u_ref)), np.max(np.abs(v_ref)))

with torch.no_grad():
    u_pred = net(torch.tensor(coords, dtype=torch.float32)).numpy()
print("PRED max|u| max|v|:", np.abs(u_pred[:, 0]).max(), np.abs(u_pred[:, 1]).max())

mask = np.abs(coords[:, 0] - coords[:, 0].max()) < 1e-9
pm = np.linalg.norm(u_pred[mask], axis=1)
rm = np.linalg.norm(np.stack([u_ref[mask], v_ref[mask]], axis=1), axis=1)
print(f"loaded-face (x={coords[:,0].max():.1f}): mean|pred|={pm.mean():.4e} "
      f"mean|ref|={rm.mean():.4e} ratio={pm.mean()/max(rm.mean(),1e-30):.2f}")

# von Mises head-to-head, incl. the same exclusion convention
geo = {'r': float(sampler.r.detach()), 'W': sampler.W, 'H': sampler.H,
       'size': 0.0}
centers = [loc for _, loc in singular_locations('plate_hole', geo)]
r_used = default_exclusion_radius(coords, centers)

# Energy-balance on the exact train quadrature
sigma_inf = 1e6 / 1e11
interior, loaded = _plate_hole_energy_context(sampler, sigma_inf, 'cpu', 3200)
phys_t = PlaneStressElasticity(E=210e9 / 1e11, nu=0.3)
u_s = (1e6 * sampler.W) / 210e9
scales = {'energy': 0.5 * (phys_t.E * u_s) * (u_s / 2.0)}
lf = XPINNLoss(phys_t, weights={'pde': 0, 'dirichlet': 0, 'neumann': 0,
                                'interface_u': 0, 'interface_t': 0}, scales=scales)
net.eval()
no_load = [{'x': loaded[0]['x'].detach(), 'y': loaded[0]['y'].detach(),
            't_x': torch.zeros_like(loaded[0]['t_x']),
            't_y': torch.zeros_like(loaded[0]['t_y']),
            'length': loaded[0]['length']}]
strain_only = float(lf.energy_loss(net, interior, no_load))
pi_full = float(lf.energy_loss(net, interior, loaded))
work = -(pi_full - strain_only)
print(f"\nPI full={pi_full:.6e}  strain-only={strain_only:.6e}  work={work:.6e}")
print(f"expected exact-solution signals: PI*=-4, strain_only*=+4, work*=+8 (dimensionless)")
print(f"strain share per panel: the field's strain is concentrated here ->")
for i, d in enumerate(interior):
    s = float(lf.energy_loss(net, [d], no_load))
    print(f"  panel {i} (area {d['area']:.4f}): strain d-ratio {s:.3f}")

# Profile along the load axis y=0 (through the concentration point (r,0)=hole tip)
xs = np.linspace(0.31, 2.0, 30)
ys = np.zeros_like(xs)
with torch.no_grad():
    prof = net(torch.tensor(np.stack([xs, ys], axis=1), dtype=torch.float32)).numpy()
near = coords[:, 1] < 0.02
for xi in [0.35, 0.6, 1.0, 1.5, 1.9]:
    i = int(np.argmin(np.abs(xs - xi)))
    j = np.argmin(np.abs(coords[:, 0] - xi))
    print(f"x={xi:.2f} y=0: pred u={prof[i,0]:.3e} v={prof[i,1]:.3e} | "
          f"ref(u={u_ref[j]:.3e}, v={v_ref[j]:.3e})")