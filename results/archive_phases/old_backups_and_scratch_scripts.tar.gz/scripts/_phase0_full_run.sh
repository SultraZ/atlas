#!/usr/bin/env bash
set -u
cd /home/sultra/atlas_main
export PYTHONUNBUFFERED=1
PY=/home/sultra/miniconda3/envs/Atlas/bin/python

run() {
  bench=$1
  ep=$2
  echo "================ $(date '+%Y-%m-%d %H:%M:%S') :: full-lbfgs :: $bench (epochs=$ep) ================"
  $PY tests/validate_all_benchmarks.py --benchmark "$bench" --epochs "$ep" --lbfgs
  mkdir -p results/phase0_full/lbfgs
  for f in validation.json model.pt convergence.png fem_comparison.png displacement.png stress.png deformed.png; do
    if [ -f "results/${bench}_${f}" ]; then
      cp "results/${bench}_${f}" "results/phase0_full/lbfgs/${bench}_${f}"
    fi
  done
  rm -f results/${bench}_validation.json results/${bench}_model.pt results/${bench}_*.png
  echo "SNAPSHOT done full-lbfgs $bench"
}

run cantilever 11000
run l_bracket 5000
run plate_hole 5000

echo "PHASE0_FULL_DONE $(date '+%Y-%m-%d %H:%M:%S')"
