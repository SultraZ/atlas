"""
loss_functions.py - Comprehensive Loss Function Implementation for XPINN
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, Tuple, List, Optional
from atlas.physics import PlaneStressElasticity


class XPINNLoss:
    def __init__(self, physics: PlaneStressElasticity,
                 weights: Optional[Dict[str, float]] = None,
                 scales: Optional[Dict[str, float]] = None):
        """
        scales: optional per-term SQUARED reference values used to make each
        loss component dimensionless ~O(1) (see atlas_main.train_forward_solver
        for where they come from). Keys: pde, dirichlet, neumann,
        interface_u, interface_t. Without it the raw (unit-ful) losses create
        two failure modes (both observed live):
          - physical units: pde ~ (1e9)^2 dominating / float32-frozen,
          - stress_scale-divided units: every term ~1e-8..1e-10 so the
            trivially-zero "elasticity" field (which scores ~0 everywhere and
            only "misses" the tiny scaled load) mathematically wins over the
            true solution, and training collapses into zero deformation.
        Each loss method below divides by its reference^2 so that "ignoring
        the load" costs O(1) and the true solution's residuals are ~0.
        """
        self.physics = physics
        self.weights = weights or {
            'pde': 1.0,
            'dirichlet': 100.0,
            'neumann': 10.0,
            'interface_u': 10.0,
            'interface_t': 10.0
        }
        self.scales = {
            'pde': 1.0, 'dirichlet': 1.0, 'neumann': 1.0,
            'interface_u': 1.0, 'interface_t': 1.0, 'energy': 1.0
        }
        if scales:
            self.scales.update(scales)

        # Global-equilibrium (resultant) constraints. Each dict targets the
        # NET reaction force/moment integrals on a constrained section so the
        # soft-physics loss can no longer shrink the whole displacement field
        # toward zero (the homogeneous zero-load state) to cheaply zero the
        # PDE term - see atlas_main._loss_scales / cantilever notes.
        # Expected keys per entry:
        #   subdomain : int
        #   x, y      : points on the constrained cross-section
        #   targets   : dict of label -> (value, scale)  value is the target
        #               mean traction (force per unit length over the section),
        #               scale is its characteristic magnitude for normalization
        self.resultants: Optional[List[Dict]] = None

        # energy_context: (interior_cuts, loaded_edges) enabling the signed
        # total-potential-energy term (monolith only). See energy_loss().
        self.energy_context: Optional[Tuple[List[Dict], List[Dict]]] = None

        # anchor_data: (coords, targets, weight) for a sparse set of interior
        # points whose displacement is softly pinned to a physics-derived
        # field (EB tip estimate etc.). This is the "physics warm anchor" that
        # keeps local-search optimizers from collapsing the field amplitude
        # during the early fine-tune (the resultant constraint alone proved
        # insufficient on the cantilever). Normalized by the displacement
        # scale like the dirichlet term.
        self.anchor_data: Optional[Tuple[torch.Tensor, torch.Tensor, float]] = None

    def anchor_loss(self, network: nn.Module,
                    coords: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        return torch.mean((network(coords) - targets) ** 2) / self.scales['dirichlet']

    def resultant_loss(self, network: nn.Module, data: Dict,
                       weight: float) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Enforce global force/moment equilibrium on a constrained section.

        For an exact elastic solution the NET traction over the loaded
        end and the reaction over the clamp must balance. The cantilever
        benchmark is homogeneous-linear, so a soft PDE loss alone leaves the
        field amplitude a free knob: shrinking displacement to zero cheaply
        reduces every interior residual, and only the (tiny) Neumann term
        fights back. These section-means of sigma_xy and (y-yc)*sigma_xx are
        LINEAR in the field amplitude, so they pin the load response exactly.
        """
        x = data['x'].detach().requires_grad_(True)
        y = data['y'].detach().requires_grad_(True)
        coords = torch.cat([x, y], dim=1)
        uv = network(coords)
        u, v = uv[:, 0:1], uv[:, 1:2]
        eps_xx, eps_yy, eps_xy = self.physics.compute_strains(u, v, x, y)
        sig_xx, sig_yy, sig_xy = self.physics.compute_stresses(eps_xx, eps_yy, eps_xy)

        total = torch.tensor(0.0, device=x.device)
        losses = {}
        loss_weight = data.get('weight', weight)
        for label, (target, scale) in data['targets'].items():
            if label == 'sxx':                    # section mean of axial
                pred = torch.mean(sig_xx)
            elif label == 'sxy':                  # section mean of shear
                pred = torch.mean(sig_xy)
            elif label == 'moment':               # section mean of (y-yc)*sig_xx
                pred = torch.mean((y - data['y_center']) * sig_xx)
            else:
                raise ValueError(f"Unknown resultant target: {label}")
            term = ((pred - target) ** 2) / (scale ** 2)
            total = total + loss_weight * term
            losses[label] = term
        return total, losses

    def pde_loss(self, network: nn.Module, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        x = x.requires_grad_(True)
        y = y.requires_grad_(True)
        coords = torch.cat([x, y], dim=1)
        uv = network(coords)
        u, v = uv[:, 0:1], uv[:, 1:2]

        eps_xx, eps_yy, eps_xy = self.physics.compute_strains(u, v, x, y)
        sig_xx, sig_yy, sig_xy = self.physics.compute_stresses(eps_xx, eps_yy, eps_xy)
        res_x, res_y = self.physics.compute_equilibrium_residuals(sig_xx, sig_yy, sig_xy, x, y)
        return torch.mean(res_x**2 + res_y**2) / self.scales['pde']

    def energy_loss(self, network: nn.Module, interior: List[Dict],
                    loaded_edges: List[Dict]) -> torch.Tensor:
        """
        Total potential energy PI = 1/2 * integral(sigma:eps) - integral(t.u)
        over the (monolith) domain, MINIMIZED directly (signed value kept).

        This is the decisive fix for the amplitude degeneracy that plagues the
        pointwise strong-form (PDE-residual) loss on the cantilever: for a
        homogeneous-linear problem, *residual* training lets the optimizer
        shrink the whole field toward zero ("quiet field") because every
        residual term scales with amplitude ~alpha^2; only the tiny Neumann
        term resists, and local-search solvers exploit that. The potential-
        energy functional is quadratic in the field (strain energy) MINUS
        linear in the field (external-load work), so its minimization has the
        amplitude pinned ELIMINATIONALLY (d/dalpha: alpha*stiff = load, exactly
        the right deflection). Boundary conditions are kept soft (Dirichlet via
        the usual penalty; traction-free edges contribute no work term; the
        loaded edge enters through -integral(t_bar.u)). PI is a signed scalar:
        at the exact solution it equals -1/2 * (load work) < 0, and no least
        -squares square is applied here.

        interior: list of subdomain-data dicts (x, y) -> strain-energy block.
        loaded_edges: list of boundary dicts of type 'neumann' that carry the
        APPLIED traction (their t_x/t_y and the geometric panel length);
        free edges and wall (dirichlet) entries are excluded by the caller.
        Every dict may carry an 'area'/'length' (numerical quadrature weight
        for the panel). Falls back to raw means if absent.
        """
        n_sub = len(interior)
        strain = torch.tensor(0.0, device=self.device_or(interior))
        px = py = None
        for data in interior:
            x = data['x'].requires_grad_(True)
            y = data['y'].requires_grad_(True)
            coords = torch.cat([x, y], dim=1)
            uv = network(coords)
            u, v = uv[:, 0:1], uv[:, 1:2]
            eps_xx, eps_yy, eps_xy = self.physics.compute_strains(u, v, x, y)
            sig_xx, sig_yy, sig_xy = self.physics.compute_stresses(eps_xx, eps_yy, eps_xy)
            energy_density = 0.5 * (sig_xx * eps_xx + sig_yy * eps_yy + 2.0 * sig_xy * eps_xy)
            area = float(data.get('area', 1.0))
            strain = strain + area * torch.mean(energy_density)

        work = torch.tensor(0.0, device=strain.device)
        for bc in loaded_edges:
            x = bc['x'].requires_grad_(True)
            y = bc['y'].requires_grad_(True)
            coords = torch.cat([x, y], dim=1)
            uv = network(coords)
            length = float(bc.get('length', 1.0))
            t_dot_u = bc['t_x'] * uv[:, 0:1] + bc['t_y'] * uv[:, 1:2]
            work = work + length * torch.mean(t_dot_u)

        # PI is normalized to be O(1) against the characteristic strain
        # energy so its gradient is well scaled (units cancel like the rest
        # of the scaled loss).
        return (strain - work) / self.scales['energy']

    @staticmethod
    def device_or(data) -> torch.device:
        for d in data:
            return d['x'].device
        return torch.device('cpu')

    def dirichlet_loss(self, network: nn.Module, x: torch.Tensor, y: torch.Tensor,
                       u_prescribed: torch.Tensor, v_prescribed: torch.Tensor,
                       constrain_u: bool = True, constrain_v: bool = True) -> torch.Tensor:
        """
        Supports partial constraints (e.g. symmetry rollers).
        """
        coords = torch.cat([x, y], dim=1)
        uv = network(coords)
        u_pred, v_pred = uv[:, 0:1], uv[:, 1:2]

        loss = torch.tensor(0.0, device=x.device)
        if constrain_u:
            loss = loss + torch.mean((u_pred - u_prescribed)**2)
        if constrain_v:
            loss = loss + torch.mean((v_pred - v_prescribed)**2)
        return loss / self.scales['dirichlet']

    def neumann_loss(self, network: nn.Module, x: torch.Tensor, y: torch.Tensor,
                     n_x: torch.Tensor, n_y: torch.Tensor,
                     t_prescribed_x: torch.Tensor, t_prescribed_y: torch.Tensor) -> torch.Tensor:
        x = x.requires_grad_(True)
        y = y.requires_grad_(True)
        coords = torch.cat([x, y], dim=1)
        uv = network(coords)
        u, v = uv[:, 0:1], uv[:, 1:2]

        eps_xx, eps_yy, eps_xy = self.physics.compute_strains(u, v, x, y)
        sig_xx, sig_yy, sig_xy = self.physics.compute_stresses(eps_xx, eps_yy, eps_xy)
        t_x, t_y = self.physics.compute_surface_traction(sig_xx, sig_yy, sig_xy, n_x, n_y)
        return torch.mean((t_x - t_prescribed_x)**2 + (t_y - t_prescribed_y)**2) / self.scales['neumann']

    def interface_displacement_loss(self, network_A: nn.Module, network_B: nn.Module,
                                    x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        coords = torch.cat([x, y], dim=1)
        uv_A = network_A(coords)
        uv_B = network_B(coords)
        return torch.mean((uv_A - uv_B)**2) / self.scales['interface_u']

    def interface_traction_loss(self, network_A: nn.Module, network_B: nn.Module,
                                x: torch.Tensor, y: torch.Tensor,
                                n_x: torch.Tensor, n_y: torch.Tensor) -> torch.Tensor:
        x = x.requires_grad_(True)
        y = y.requires_grad_(True)
        coords = torch.cat([x, y], dim=1)

        # Network A
        uv_A = network_A(coords)
        u_A, v_A = uv_A[:, 0:1], uv_A[:, 1:2]
        eps_xx_A, eps_yy_A, eps_xy_A = self.physics.compute_strains(u_A, v_A, x, y)
        sig_xx_A, sig_yy_A, sig_xy_A = self.physics.compute_stresses(eps_xx_A, eps_yy_A, eps_xy_A)
        t_x_A, t_y_A = self.physics.compute_surface_traction(sig_xx_A, sig_yy_A, sig_xy_A, n_x, n_y)

        # Network B (opposite normal)
        x = x.detach().requires_grad_(True)
        y = y.detach().requires_grad_(True)
        coords = torch.cat([x, y], dim=1)
        uv_B = network_B(coords)
        u_B, v_B = uv_B[:, 0:1], uv_B[:, 1:2]
        eps_xx_B, eps_yy_B, eps_xy_B = self.physics.compute_strains(u_B, v_B, x, y)
        sig_xx_B, sig_yy_B, sig_xy_B = self.physics.compute_stresses(eps_xx_B, eps_yy_B, eps_xy_B)
        t_x_B, t_y_B = self.physics.compute_surface_traction(sig_xx_B, sig_yy_B, sig_xy_B, -n_x, -n_y)

        return torch.mean((t_x_A + t_x_B)**2 + (t_y_A + t_y_B)**2) / self.scales['interface_t']

    def compute_total_loss(self, model, subdomain_data: List[Dict],
                           interface_data: List[Dict],
                           boundary_data: List[Dict]) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Aggregate every loss term (weighted by self.weights) across all
        subdomains/boundaries/interfaces for a given XPINNModel.

        Lives on XPINNLoss (not XPINNTrainer) specifically so that anything
        holding a bare XPINNLoss instance - like InverseDesignOptimizer's
        forward_solve_step(), which is handed an XPINNLoss by
        atlas_main.run_inverse_design_on_plate() - can call it directly.
        XPINNTrainer.compute_total_loss() below just forwards to this so
        there's one implementation, not two that can drift apart.
        """
        device = model.device
        losses = {
            'pde': torch.tensor(0.0, device=device),
            'dirichlet': torch.tensor(0.0, device=device),
            'neumann': torch.tensor(0.0, device=device),
            'interface_u': torch.tensor(0.0, device=device),
            'interface_t': torch.tensor(0.0, device=device),
            'energy': torch.tensor(0.0, device=device)
        }

        for i, data in enumerate(subdomain_data):
            network = model.get_subdomain_network(i)
            losses['pde'] += self.pde_loss(network, data['x'], data['y'])

        for bc in boundary_data:
            network = model.get_subdomain_network(bc['subdomain'])
            if bc['type'] == 'dirichlet':
                constrain_u = bc.get('constrain_u', True)
                constrain_v = bc.get('constrain_v', True)
                losses['dirichlet'] += self.dirichlet_loss(
                    network, bc['x'], bc['y'],
                    bc['u_prescribed'], bc['v_prescribed'],
                    constrain_u=constrain_u, constrain_v=constrain_v
                )
            elif bc['type'] == 'neumann':
                losses['neumann'] += self.neumann_loss(
                    network, bc['x'], bc['y'],
                    bc['n_x'], bc['n_y'], bc['t_x'], bc['t_y']
                )
        
        for interface in interface_data:
            net_A = model.get_subdomain_network(interface['subdomain_A'])
            net_B = model.get_subdomain_network(interface['subdomain_B'])
            losses['interface_u'] += self.interface_displacement_loss(
                net_A, net_B, interface['x'], interface['y']
            )
            losses['interface_t'] += self.interface_traction_loss(
                net_A, net_B, interface['x'], interface['y'],
                interface['n_x'], interface['n_y']
            )

        # Total-potential-energy term (optional). Only meaningful for a
        # monolith (a single net spanning the whole domain). PI is minimized
        # as a SIGNED scalar - it must not be squared and must not be folded
        # into a penalty weight; the load enters through the minus-work part.
        if getattr(model, 'monolith', False) and self.energy_context is not None:
            cuts, loaded = self.energy_context
            # interior dicts already carry 'area' quadrature weights set by
            # the caller; loaded-edge dicts carry both 'length' and the
            # applied traction.
            net_all = model.get_subdomain_network(0)
            losses['energy'] = self.energy_loss(net_all, cuts, loaded)

        # Global-equilibrium resultants (optional). Their residual gradient is
        # linear in field amplitude, so they hold the load-response amplitude
        # fixed and stop the soft-PDE loss from collapsing the field to zero.
        if self.resultants is not None:
            for r in self.resultants:
                network = model.get_subdomain_network(r['subdomain'])
                rloss, rparts = self.resultant_loss(network, r, self.weights['neumann'])
                losses['neumann'] += rloss

        # Sparse physics-derived displacement anchor (optional; monolith).
        if self.anchor_data is not None:
            coords, targets, weight = self.anchor_data
            anet = model.get_subdomain_network(0)
            losses['dirichlet'] += weight * self.anchor_loss(anet, coords, targets)

        total = sum(self.weights[key] * losses[key] for key in losses if key != 'energy')
        total = total + losses['energy']
        return total, losses


class XPINNTrainer:
    def __init__(self, xpinn_model, physics: PlaneStressElasticity,
                 learning_rate: float = 1e-3,
                 loss_weights: Optional[Dict[str, float]] = None,
                 loss_scales: Optional[Dict[str, float]] = None):
        self.model = xpinn_model
        self.physics = physics
        self.loss_fn = XPINNLoss(physics, loss_weights, scales=loss_scales)
        # Seed of the per-component weights used by adaptive balancing so a
        # phase-2 run can drift weights without permanently editing them.
        self._base_weights: Dict[str, float] = dict(self.loss_fn.weights)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=learning_rate)
        # NOTE: verbose=True was removed from ReduceLROnPlateau in newer
        # PyTorch releases (2.4+) and raises a TypeError there. LR-drop
        # messages are now printed manually in train() by comparing the LR
        # before/after scheduler.step() instead of relying on the kwarg.
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer, mode='min', factor=0.5, patience=1000
        )
        self.history = {
            'total': [], 'pde': [], 'dirichlet': [],
            'neumann': [], 'interface_u': [], 'interface_t': [], 'energy': []
        }
        # Index into history['total'] where the Adam stage ends and L-BFGS
        # begins (None until train() actually runs). Used by
        # visualization.plot_training_convergence to mark the stage switch.
        self.adam_epoch_count: Optional[int] = None

    def compute_total_loss(self, subdomain_data: List[Dict],
                           interface_data: List[Dict],
                           boundary_data: List[Dict]) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        # Delegates to XPINNLoss.compute_total_loss (see its docstring) so
        # there's a single implementation shared with InverseDesignOptimizer.
        return self.loss_fn.compute_total_loss(
            self.model, subdomain_data, interface_data, boundary_data
        )

    def train_step(self, subdomain_data, interface_data, boundary_data) -> Dict[str, float]:
        self.optimizer.zero_grad()
        total_loss, loss_components = self.compute_total_loss(
            subdomain_data, interface_data, boundary_data
        )
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
        self.optimizer.step()

        self.history['total'].append(total_loss.item())
        for key, val in loss_components.items():
            self.history[key].append(val.item())
        return {key: val.item() for key, val in loss_components.items()}

    def _component_grad_norms(self, subdomain_data, interface_data, boundary_data,
                              keys) -> Dict[str, float]:
        """Unweighted per-component gradient norms w.r.t. all model params.

        Each component of the loss is a separate scalar living on the freshly
        built autograd graph, so its gradient can be read off independently.
        Used only by the phase-2 adaptive weight balancing (every
        adapt_every epochs), never during a normal step.
        """
        params = list(self.model.parameters())
        self.optimizer.zero_grad()
        _total, comps = self.compute_total_loss(
            subdomain_data, interface_data, boundary_data)
        norms: Dict[str, float] = {}
        for key in keys:
            val = comps.get(key)
            if val is None or not val.requires_grad:
                continue
            grads = torch.autograd.grad(
                val, params, grad_outputs=torch.ones_like(val),
                retain_graph=True, allow_unused=True)
            norm2 = torch.sum(torch.stack([
                (g if g is not None else torch.tensor(0.0, device=val.device)).pow(2).sum()
                for g in grads
            ]))
            norms[key] = norm2.sqrt().item()
        return norms

    def adapt_weights(self, subdomain_data, interface_data, boundary_data,
                      keys, lo: float = 0.2, hi: float = 5.0) -> Dict[str, float]:
        """Gradient-norm balancing of the per-component loss weights.

        Terms whose network gradient is comparatively large are over-driving
        the step; their weight is reduced and the under-driven terms are
        raised, so each component contributes a comparable gradient magnitude
        (Wang et al. 2021 style learning-rate annealing, adapted to per-term
        weights). Individual weights are clamped to [lo, hi] x their original
        value so a term can never be switched off or exploded by drift, and
        each adaptation is itself magnitude-bounded.
        """
        norms = self._component_grad_norms(
            subdomain_data, interface_data, boundary_data, keys)
        if not norms:
            return {}
        med = float(np.median(list(norms.values())))
        out: Dict[str, float] = {}
        for key, g in norms.items():
            if g <= 0.0 or key not in self._base_weights:
                continue
            base = self._base_weights[key]
            factor = float(np.clip(med / g, 0.5, 2.0))
            new_w = float(np.clip(base * factor, base * lo, base * hi))
            self.loss_fn.weights[key] = new_w
            out[key] = new_w
        return out

    def train(self, subdomain_data, interface_data, boundary_data,
              epochs: int = 10000, print_every: int = 500,
              use_lbfgs: bool = True, lbfgs_steps: int = 25,
              lbfgs_max_iter_per_step: int = 20, lbfgs_history_size: int = 50,
              lbfgs_print_every: int = 5,
              adaptive_weights: bool = False, adapt_every: int = 100):
        """
        Two-stage training, matching the paper's stated methodology
        ("The optimizer for training is Adam, and for fine-tuning, L-BFGS."):

          Stage 1 (Adam, `epochs` steps): fast, robust, stochastic-friendly
          first-order optimization. Gets the network from a random init into
          a good basin quickly, but Adam only uses gradient *direction* (with
          per-parameter adaptive scaling) - it has no model of loss curvature,
          so it tends to plateau well short of the best achievable residual.

          Stage 2 (L-BFGS, `lbfgs_steps` x `lbfgs_max_iter_per_step` internal
          iterations, only if use_lbfgs=True): quasi-Newton fine-tuning.
          L-BFGS builds a low-rank approximation of the loss Hessian from the
          last `lbfgs_history_size` gradient/step pairs and takes much better
          (curvature-aware) steps once you're already close to a minimum -
          exactly the regime Adam leaves you in. This is standard practice
          in the PINN literature (Raissi et al. 2019 and most work since)
          for squeezing the last 1-2 orders of magnitude out of the PDE
          residual after Adam plateaus.

        Set use_lbfgs=False to reproduce the old Adam-only behavior.
        """
        print("Starting XPINN Training (Stage 1: Adam)...")
        print("=" * 60)
        for epoch in range(epochs):
            losses = self.train_step(subdomain_data, interface_data, boundary_data)
            lr_before = self.optimizer.param_groups[0]['lr']
            self.scheduler.step(self.history['total'][-1])
            lr_after = self.optimizer.param_groups[0]['lr']
            if lr_after < lr_before:
                print(f"  [scheduler] Epoch {epoch+1}: LR reduced {lr_before:.3e} -> {lr_after:.3e}")
            if adaptive_weights and (epoch + 1) % adapt_every == 0:
                adjusted = self.adapt_weights(
                    subdomain_data, interface_data, boundary_data,
                    list(self.loss_fn.weights.keys()))
                if adjusted:
                    print("  [adaptive] epoch {:5d}: ".format(epoch + 1)
                          + ", ".join(f"{k}={v:.4g}" for k, v in adjusted.items()))
            if (epoch + 1) % print_every == 0:
                total = self.history['total'][-1]
                print(f"Epoch {epoch+1:5d} | Total Loss: {total:.6e}")
                print(f"  PDE: {losses['pde']:.4e} | "
                      f"Dirichlet: {losses['dirichlet']:.4e} | "
                      f"Neumann: {losses['neumann']:.4e}")
                print(f"  Interface u: {losses['interface_u']:.4e} | "
                      f"Interface t: {losses['interface_t']:.4e}")
        print("=" * 60)
        print(f"Adam stage complete! ({epochs} epochs, final loss "
              f"{self.history['total'][-1]:.6e})")

        self.adam_epoch_count = len(self.history['total'])

        if use_lbfgs:
            self.train_lbfgs(
                subdomain_data, interface_data, boundary_data,
                n_lbfgs_steps=lbfgs_steps,
                max_iter_per_step=lbfgs_max_iter_per_step,
                history_size=lbfgs_history_size,
                print_every=lbfgs_print_every,
            )
        else:
            print("(use_lbfgs=False - skipping stage 2)")

        print("Training Complete!")

    def _lbfgs_closure_factory(self, subdomain_data, interface_data, boundary_data):
        def closure():
            self.lbfgs_optimizer.zero_grad()
            total_loss, loss_components = self.compute_total_loss(
                subdomain_data, interface_data, boundary_data
            )
            total_loss.backward()
            # Stash components as a side effect so train_lbfgs() can log
            # them after step() returns - step()/closure() may call this
            # several times internally (line search), we just keep the
            # values from whichever call was most recent.
            self._last_lbfgs_loss_components = loss_components
            return total_loss
        return closure

    def train_lbfgs(self, subdomain_data, interface_data, boundary_data,
                     n_lbfgs_steps: int = 25, max_iter_per_step: int = 20,
                     history_size: int = 50, line_search_fn: str = 'strong_wolfe',
                     tolerance_grad: float = 1e-8, tolerance_change: float = 1e-10,
                     print_every: int = 5):
        """
        Stage 2 fine-tuning with L-BFGS. See train()'s docstring for why.

        Deliberately does NOT apply torch.nn.utils.clip_grad_norm_ here,
        unlike train_step()'s Adam updates. The Adam-stage clip exists to
        stop occasional large PDE-residual gradients from causing a
        destabilizing first-order step. L-BFGS already has its own
        safeguard against bad steps - the strong-Wolfe line search - and its
        step *direction* comes from the approximate inverse-Hessian applied
        to the gradient, not the raw gradient magnitude. Clipping the
        gradient before L-BFGS sees it would silently corrupt the curvature
        (secant-pair) history it's building without adding any real
        stability benefit, so we leave gradients unclipped in this stage.

        `n_lbfgs_steps` outer Python-level calls to optimizer.step(closure)
        exist purely so we can print progress periodically - the optimizer
        object (and its internal curvature history) persists across all of
        them; it is not reset between outer steps. Each step() call itself
        runs up to `max_iter_per_step` internal L-BFGS iterations (each of
        which may evaluate `closure` more than once for the line search).
        """
        self.lbfgs_optimizer = torch.optim.LBFGS(
            self.model.parameters(),
            lr=1.0,
            max_iter=max_iter_per_step,
            history_size=history_size,
            line_search_fn=line_search_fn,
            tolerance_grad=tolerance_grad,
            tolerance_change=tolerance_change,
        )

        closure = self._lbfgs_closure_factory(subdomain_data, interface_data, boundary_data)

        print("=" * 60)
        print("Starting XPINN Training (Stage 2: L-BFGS fine-tuning)...")
        print("=" * 60)

        for step in range(n_lbfgs_steps):
            loss_val = self.lbfgs_optimizer.step(closure)
            total = loss_val.item() if torch.is_tensor(loss_val) else float(loss_val)
            comp = self._last_lbfgs_loss_components

            self.history['total'].append(total)
            for key, val in comp.items():
                self.history[key].append(val.item())

            if (step + 1) % print_every == 0 or step == n_lbfgs_steps - 1:
                print(f"L-BFGS step {step+1:3d}/{n_lbfgs_steps} | Total Loss: {total:.6e}")
                print(f"  PDE: {comp['pde'].item():.4e} | "
                      f"Dirichlet: {comp['dirichlet'].item():.4e} | "
                      f"Neumann: {comp['neumann'].item():.4e}")
                print(f"  Interface u: {comp['interface_u'].item():.4e} | "
                      f"Interface t: {comp['interface_t'].item():.4e}")

        print("=" * 60)
        print(f"L-BFGS stage complete! (final loss {self.history['total'][-1]:.6e})")