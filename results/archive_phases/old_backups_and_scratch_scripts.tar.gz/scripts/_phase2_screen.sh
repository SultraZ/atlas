#!/usr/bin/env bash
# Phase-2 adaptive-weight screen driver (runs detached under `screen`).
# args: PHASE EPOCHS ADAPT_EVERY BENCHES
set -u
cd /home/sultra/atlas_main
export PYTHONUNBUFFERED=1
PY=/home/sultra/miniconda3/envs/Atlas/bin/python
PHASE=${1:-phase2}
EPOCHS=${2:-3000}
ADAPT_EVERY=${3:-100}
BENCHES=${4:-"l_bracket plate_hole"}
LOGSDIR=results/$PHASE/lbfgs
mkdir -p "$LOGSDIR"

for bench in $BENCHES; do
  LOG="$LOGSDIR/${bench}_screen.log"
  echo "================ $(date '+%Y-%m-%d %H:%M:%S') :: $PHASE :: lbfgs+adaptive :: $bench (epochs=$EPOCHS adapt=$ADAPT_EVERY) ================"
  timeout 3240 "$PY" tests/validate_all_benchmarks.py --benchmark "$bench" \
      --epochs "$EPOCHS" --lbfgs --adaptive-weights --adapt-every "$ADAPT_EVERY" \
      > "$LOG" 2>&1
  echo "rc=$? $PHASE $bench"
  # Snapshot artifacts so the validation JSON lives beside the run log
  # (mirrors scripts/_phase_run.sh; required by _poll_phase2.sh).
  for f in validation.json model.pt convergence.png fem_comparison.png displacement.png stress.png deformed.png; do
    if [ -f "results/${bench}_${f}" ]; then
      cp "results/${bench}_${f}" "$LOGSDIR/${bench}_${f}"
    fi
  done
  echo "SNAPSHOT done $PHASE $bench"
done
echo "PHASE2_SCREEN_DONE $(date '+%Y-%m-%d %H:%M:%S')"
