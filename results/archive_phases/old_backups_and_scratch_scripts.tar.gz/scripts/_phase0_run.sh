#!/usr/bin/env bash
# Throwaway Phase 0 driver (delete after use). Runs each benchmark Adam-only
# and Adam+L-BFGS at the reduced screening budget and snapshots the artifacts
# into results/phase0/{adam,lbfgs}/ so the L-BFGS variable is isolated.
set -u
cd /home/sultra/atlas_main || exit 1
PY=/home/sultra/miniconda3/envs/Atlas/bin/python
EPOCHS="${PHASE0_EPOCHS:-2000}"
mkdir -p results/phase0

for cfg in adam lbfgs; do
  if [ "$cfg" = "lbfgs" ]; then extra="--lbfgs"; else extra=""; fi
  for bench in cantilever l_bracket plate_hole; do
    echo "================ $(date '+%F %T') :: $cfg :: $bench ================"
    $PY tests/validate_all_benchmarks.py --benchmark "$bench" --epochs "$EPOCHS" $extra
    mkdir -p "results/phase0/$cfg"
    for f in validation.json model.pt convergence.png fem_comparison.png displacement.png stress.png deformed.png; do
      src="results/${bench}_${f}"
      [ -f "$src" ] && cp "$src" "results/phase0/$cfg/${bench}_${f}"
    done
    echo "SNAPSHOT done $cfg $bench"
  done
done
echo "PHASE0_ALL_DONE"
