#!/usr/bin/env bash
# Detached Phase-4 MPE screen launcher. Spawns _phase4_mpe_screen.sh via setsid
# so the run survives this shell closing.
set -u
cd /home/sultra/atlas_main
mkdir -p results/phase4/mpe results/phase4/driver
echo "LAUNCH_TS $(date '+%Y-%m-%d %H:%M:%S')"
setsid bash scripts/_phase4_mpe_screen.sh phase4 2000 \
    >> results/phase4/driver/screen.log 2>&1 < /dev/null &
echo "SCREEN_SPAWNED pid=$!"
sleep 2
cat results/phase4/driver/screen.log 2>/dev/null | tail -2