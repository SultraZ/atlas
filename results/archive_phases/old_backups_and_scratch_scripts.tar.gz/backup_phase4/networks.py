"""
networks.py - Neural Network Architectures for XPINN
Implements subdomain-specific networks for domain decomposition
"""

import torch
import torch.nn as nn
from typing import List, Optional


class SubdomainNetwork(nn.Module):
    """
    Fully-connected neural network for a single subdomain
    
    Architecture:
        Input (x, y) -> Hidden Layers -> Output (u, v)
    
    Uses Tanh activation for smooth displacement fields
    which is important for computing accurate gradients.
    """
    
    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 2,
        hidden_layers: int = 4,
        neurons_per_layer: int = 64,
        activation: nn.Module = nn.Tanh(),
        output_scale: Optional[float] = None,
    ):
        """
        Initialize the subdomain network

        Args:
            input_dim: Number of input features (default: 2 for x, y)
            output_dim: Number of outputs (default: 2 for u, v)
            hidden_layers: Number of hidden layers (default: 4)
            neurons_per_layer: Neurons in each hidden layer (default: 64)
            activation: Activation function (default: Tanh)
            output_scale: Optional characteristic displacement (meters) the
                network output is multiplied by. Random-init outputs (~0.05
                from Xavier) are then ~u_s-scaled instead of 10-100x u_s, so
                the dominant gradient from initialization is shaping the
                displacement field rather than simply shrinking its amplitude
                (which stalls the optimizer on the near-zero "trivial" field).
        """
        super().__init__()

        self.input_dim = input_dim
        self.output_dim = output_dim
        self.output_scale = output_scale
        
        # Build network layers
        layers = []
        
        # Input layer
        layers.append(nn.Linear(input_dim, neurons_per_layer))
        layers.append(activation)
        
        # Hidden layers
        for _ in range(hidden_layers - 1):
            layers.append(nn.Linear(neurons_per_layer, neurons_per_layer))
            layers.append(activation)
        
        # Output layer (no activation for regression)
        layers.append(nn.Linear(neurons_per_layer, output_dim))
        
        self.network = nn.Sequential(*layers)
        
        # Initialize weights using Xavier initialization
        self._initialize_weights()
    
    def _initialize_weights(self):
        """Xavier initialization for better convergence"""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                nn.init.zeros_(m.bias)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass
        
        Args:
            x: Input coordinates tensor of shape (N, 2)
            
        Returns:
            Displacement tensor of shape (N, 2) containing [u, v]
        """
        out = self.network(x)
        if self.output_scale is not None:
            out = out * self.output_scale
        return out


class XPINNModel(nn.Module):
    """
    Extended Physics-Informed Neural Network with Domain Decomposition
    
    Manages multiple subdomain networks and provides unified interface
    for the XPINN training procedure.
    """
    
    def __init__(
        self,
        num_subdomains: int,
        hidden_layers: int = 4,
        neurons_per_layer: int = 64,
        device: str = 'cpu',
        output_scale: Optional[float] = None,
        monolith: bool = False,
    ):
        """
        Initialize XPINN model with multiple subdomain networks
        
        Args:
            num_subdomains: Number of subdomains for domain decomposition
            hidden_layers: Hidden layers per subdomain network
            neurons_per_layer: Neurons per hidden layer
            device: Compute device ('cpu' or 'cuda')
            output_scale: Optional characteristic-displacement scale (meters)
                passed to each SubdomainNetwork (see SubdomainNetwork.__init__).
            monolith: If True, all subdomain slots share ONE network. Used for
                warm-started forward solves (e.g. the cantilever, whose
                subdomain interface terms were observed to drag the optimizer
                out of the true bending basin). The XPINN API is unchanged:
                get_subdomain_network(i) returns the same net for every i, and
                the interface loss terms become exactly zero by construction.
        """
        super().__init__()
        
        self.num_subdomains = num_subdomains
        self.device = device
        self.monolith = monolith
        
        if monolith:
            self.subnets = nn.ModuleList([
                SubdomainNetwork(
                    hidden_layers=hidden_layers,
                    neurons_per_layer=neurons_per_layer,
                    output_scale=output_scale
                )
            ])
        else:
            # Create subdomain networks
            self.subnets = nn.ModuleList([
                SubdomainNetwork(
                    hidden_layers=hidden_layers,
                    neurons_per_layer=neurons_per_layer,
                    output_scale=output_scale
                )
                for _ in range(num_subdomains)
            ])
        
        # Move to device
        self.to(device)
    
    def forward_subdomain(
        self,
        subdomain_idx: int,
        x: torch.Tensor,
        y: torch.Tensor
    ) -> torch.Tensor:
        """
        Forward pass for a specific subdomain
        
        Args:
            subdomain_idx: Index of the subdomain (0-indexed)
            x, y: Coordinate tensors
            
        Returns:
            Displacement tensor [u, v]
        """
        coords = torch.cat([x, y], dim=1)
        return self.subnets[0 if self.monolith else subdomain_idx](coords)
    
    def get_subdomain_network(self, idx: int) -> SubdomainNetwork:
        """Get a specific subdomain network (monolith: always the one net)"""
        return self.subnets[0 if self.monolith else idx]


class AdaptiveActivation(nn.Module):
    """
    Adaptive activation function with learnable parameters
    
    Allows the network to learn optimal activation scaling:
        f(x) = activation(a * x) where 'a' is learnable
    """
    
    def __init__(self, activation: nn.Module = nn.Tanh(), init_scale: float = 1.0):
        super().__init__()
        self.activation = activation
        self.scale = nn.Parameter(torch.tensor([init_scale]))
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.activation(self.scale * x)


class ResidualBlock(nn.Module):
    """
    Residual block for deeper networks
    
    Implements: output = input + F(input)
    """
    
    def __init__(self, features: int, activation: nn.Module = nn.Tanh()):
        super().__init__()
        self.block = nn.Sequential(
            nn.Linear(features, features),
            activation,
            nn.Linear(features, features)
        )
        self.activation = activation
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.activation(x + self.block(x))


class EnhancedSubdomainNetwork(nn.Module):
    """
    Enhanced network with residual connections and normalization
    
    Better for complex stress distributions and deeper architectures.
    """
    
    def __init__(
        self,
        input_dim: int = 2,
        output_dim: int = 2,
        hidden_dim: int = 64,
        num_blocks: int = 4
    ):
        super().__init__()
        
        self.input_layer = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.Tanh()
        )
        
        self.res_blocks = nn.ModuleList([
            ResidualBlock(hidden_dim)
            for _ in range(num_blocks)
        ])
        
        self.output_layer = nn.Linear(hidden_dim, output_dim)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.input_layer(x)
        for block in self.res_blocks:
            h = block(h)
        return self.output_layer(h)


# Utility function to create XPINN model for benchmarks
def create_xpinn_for_benchmark(
    benchmark: str,
    hidden_layers: int = 4,
    neurons: int = 64,
    device: str = 'cpu',
    output_scale: Optional[float] = None,
    monolith: bool = False,
) -> XPINNModel:
    """
    Factory function to create XPINN model for specific benchmarks
    
    Args:
        benchmark: One of 'cantilever', 'l_bracket', 'plate_hole'
        hidden_layers: Number of hidden layers
        neurons: Neurons per layer
        device: Compute device
        output_scale: Optional characteristic-displacement scale (meters)
        
    Returns:
        Configured XPINNModel instance
    """
    num_subdomains = {
        'cantilever': 2,
        'l_bracket': 3,
        'plate_hole': 3
    }
    
    if benchmark not in num_subdomains:
        raise ValueError(f"Unknown benchmark: {benchmark}")
    
    return XPINNModel(
        num_subdomains=num_subdomains[benchmark],
        hidden_layers=hidden_layers,
        neurons_per_layer=neurons,
        device=device,
        output_scale=output_scale,
        monolith=monolith,
    )
