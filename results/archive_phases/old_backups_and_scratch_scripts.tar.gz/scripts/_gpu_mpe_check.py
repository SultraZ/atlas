"""Throwaway GPU check: 2 Adam epochs + 1 L-BFGS step on the MPE path."""
import os
import sys
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from atlas.atlas_main import train_forward_solver

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"device={device}")
torch.manual_seed(42)
np.random.seed(42)
model, trainer, sampler, phys = train_forward_solver(
    'plate_hole', device=device, epochs=2, print_every=100000,
    n_interior=360, n_boundary=120, n_interface=40,
    use_lbfgs=True, lbfgs_steps=1, lbfgs_max_iter_per_step=10,
    hidden_layers=4, neurons=64, use_mpe=True)
print("GPU_MAT_E=" + str(float(trainer.history['total'][-1])))
print("GPU_MAT_PI=" + str(float(trainer.history['energy'][-1])))
assert all(np.isfinite(v) for v in trainer.history['total']), "non-finite total"
print("GPU MPE CHECK OK")